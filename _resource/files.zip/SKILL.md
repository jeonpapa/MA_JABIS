---
name: korea-drug-pricing-system
description: Korea 약가 제도 (HIRA·MOHW·NHIS·약평위·건정심) 핵심 지식과 37개 micro-rule 베이스. 약가 산정·인하·조정, 위험분담제(RSA) 설계, 경제성평가 트랙, 단독품목 면제, LOE·제네릭 정책, 산정특례, 약가협상 절차, 신속등재 경로, 사용량-약가 연동, 2026 약가제도 개편안 (제네릭 45% + 11년 단계 인하 + 그룹 1/2 + Floor rule + 기업 유형별 우대 + 약가 유연계약제) 등 한국 reimbursement 제도 전반에 대한 정확한 사실 기반 분석이 필요할 때 반드시 이 스킬을 사용하라. 특히 한국 MSD 자산 (키트루다·웰리렉·브리디온·저박사·에멘드)에 대한 분석 시 우선 trigger. 트리거 키워드 — "약가", "약평위", "위험분담", "RSA", "WAP", "가중평균가", "약가협상", "급여등재", "급여확대", "산정특례", "본인부담", "경제성평가", "ICER", "QALY", "LOE", "특허만료", "제네릭", "단독품목", "행정예고", "건정심", "심평원", "expenditure cap", "경평면제", "선별급여", "신속등재", "약가 유연계약", "기등재 의약품 인하", "혁신형 제약기업", "준혁신형 제약기업", "급여적정성 재평가", "그룹 1", "그룹 2", "Floor rule", "키트루다", "웰리렉", "브리디온", "저박사", "에멘드". 단순 약물 정보가 아닌 "한국 reimbursement 맥락에서의 분석"이 개입되는 순간 발동.
---

# Korea Drug Pricing System Knowledge Base v1.5

한국 약가 제도의 micro-rule 37개 + MSD Korea 자산별 운영 사실 + MA 전문가 시야 + MSD 운영 관점을 통합한 분석 프레임워크.

**원천 자료**: 김앤장 (고수경, 2026), 법무법인 세종 (2026.04.09), 보건복지부 보도자료 (2014.12.16), KPAD 사용자 인사이트.

이 스킬의 가치는 **한국 제도의 micro-rule + MSD Korea 운영 맥락**을 정확히 적용하는 것. 5가지 SEVERE VIOLATION 방지:

1. ❌ 이미 LOE 도래한 자산을 미래시제로 분석
2. ❌ 단독품목 면제 대상 자산에 generic 인하 영향 자동 적용
3. ❌ 추가 약가 인하 여력 소진된 자산에 추가 인하 가능성 분석
4. ❌ 기체결 RSA 자산에 RSA 구조 재조정을 가벼운 옵션으로 제시
5. ❌ KB 사실을 무시하고 일반론적 추론 전개

---

## 사용 흐름

```
[Step 1] 트리거 키워드 식별 → references/ 어느 파일을 읽을지 결정
[Step 2] 해당 reference 파일 view → 정확한 rule·자산 fact 확보
[Step 3] 분석 작성 (반드시 KR-RULE 번호 인용)
[Step 4] severe_violations.md 5개 패턴 자가 검증
```

---

## References (12개 파일)

### Lenses — 시야 (분석 관점)

| 파일 | 언제 사용 | 핵심 |
|------|----------|------|
| `ma_expert_lens.md` ⭐ NEW | 정책·뉴스 해석 시 | HIRA decision logic, 5대 전략 원칙, 정책 신호 해석법, 6-step framework |
| `msd_korea_lens.md` ⭐ NEW | MSD 자산·portfolio 분석 시 | Tier 1~3 자산 + 운영 제약 + 자산별 전략 카드 + 본사 alignment |

### Facts — 사실 base

| 파일 | 언제 사용 | KR-RULE |
|------|----------|---------|
| `quick_reference.md` | 빠른 사실 lookup (최우선) | 37 rule 한 줄 요약 |
| `pricing_rules.md` | 약가 산정·인하 분석 | 001~009, 028~030 |
| `rsa_rules.md` | RSA 설계·재계약 분석 | 003, 018~021 |
| `process_rules.md` | 등재·협상 절차 분석 | 010~017 |
| `post_marketing.md` | 사후관리·재평가 분석 | 005, 022~027 |
| `reform_2026.md` ⭐ NEW | 2026 개편안 분석 | 031~037 (Floor rule, 그룹 1/2, 11년 단계 인하) |
| `msd_assets.md` | MSD 자산별 fact 확인 | Tier 1 5개 자산 deep dive |
| `timeline_2006_2028.md` | 제도 변천사 | 17 historical case + 예정 |

### Standards — 출력·검증

| 파일 | 언제 사용 |
|------|----------|
| `severe_violations.md` | 의심스러울 때 자가 검증 (5개 위반 패턴) |
| `output_standards.md` | 분석 출력 시 (R1~R6 표준) |

---

## 빠른 트리거 가이드

| 트리거 표현 | view할 reference |
|------------|-----------------|
| "약가 인하", "WAP", "산정률", "가산" | `pricing_rules.md` |
| "위험분담", "RSA", "환급", "총액제한" | `rsa_rules.md` |
| "약평위", "협상", "고시", "행정예고" | `process_rules.md` |
| "ICER", "QALY", "산정특례", "사용량-약가 연동" | `post_marketing.md` |
| **"2026 개편", "그룹 1/2", "Floor rule", "11년 단계 인하"** ⭐ | **`reform_2026.md`** |
| **"약가 유연계약", "유연계약제"** ⭐ | `reform_2026.md` (KR-RULE-028) |
| **"혁신형 제약기업", "준혁신형", "수급안정 선도기업"** ⭐ | `reform_2026.md` (KR-RULE-033) |
| **"급여적정성 재평가", "선별급여 50/80"** ⭐ | `reform_2026.md` (KR-RULE-036) |
| "키트루다·웰리렉·브리디온·저박사·에멘드" | `msd_assets.md` + `msd_korea_lens.md` |
| "특허만료", "LOE", "제네릭" | ⚠️ `severe_violations.md` (미래시제 금지) |
| "정책 신호", "정부 발표", "건정심 의결" 해석 | `ma_expert_lens.md` |
| "HIRA 의사결정", "약평위 logic" | `ma_expert_lens.md` |
| MSD portfolio·자산 전략 | `msd_korea_lens.md` |
| 트리거 모호 시 | `quick_reference.md` |

---

## 시나리오별 view 묶음 (자주 함께 쓰이는 조합)

### 시나리오 1: 정책 뉴스 해석
1. `ma_expert_lens.md` (어떤 신뢰도 단계 시그널인지)
2. 해당 정책의 fact base (`pricing_rules.md` 또는 `reform_2026.md`)
3. `msd_korea_lens.md` (MSD 자산별 영향)

### 시나리오 2: MSD 자산 분석
1. `msd_assets.md` (해당 자산 deep dive)
2. `msd_korea_lens.md` (자산별 전략 카드)
3. applicable_rules에 명시된 KR-RULE의 fact base

### 시나리오 3: 2026 개편안 영향 분석 ⭐
1. `reform_2026.md` (개편안 7개 micro-rules)
2. `msd_korea_lens.md` (한국 MSD operating impact)
3. `severe_violations.md` (그룹 분류·Floor rule 자가 검증)

### 시나리오 4: MA 전략 수립
1. `ma_expert_lens.md` (5대 원칙 + 6-step framework)
2. `msd_korea_lens.md` (자산별 전략 카드)
3. `output_standards.md` (R1~R6 표준)

### 시나리오 5: 사실 quick check
1. `quick_reference.md` 만 view (충분한 경우 다수)

---

## 핵심 원칙 (모든 분석 공통)

1. **KB 사실 > 일반 추론**. 사실 부재 시 "정보 부재"로 명시.
2. **KR-RULE 번호 인용**. *"약평위에서 검토 가능"* 같은 generic 표현 금지.
3. **MSD 자산명 정확성** — 자산명 + INN + 한글명 (Welireg/belzutifan/웰리렉).
4. **Confidential 정보 미사용** — 미공개 RSA 수치·가격 카드 추정 금지.
5. **HIRA·MOHW·NHIS payer 관점**에서 출발.
6. **2026 개편안 사용 시** — ⚠️ "고시 개정 진행 중 — 최종 확정 아님" 명시 + Floor rule 항상 적용.
7. **두 lens의 균형** — payer logic (Lens A) + MSD 운영 (Lens B) 양쪽 시야 적용.

---

## 메타 정보

- **Version**: 1.5 (2026-04-25)
- **Curator**: 올윈 (MSD Korea MA)
- **v1.0 → v1.5 변경**:
  - `reform_2026.md` 추가 (KR-RULE-031~037)
  - `ma_expert_lens.md` 추가 (MA 전문가 시야)
  - `msd_korea_lens.md` 추가 (MSD 운영 관점)
  - SKILL.md trigger 키워드 확장
- **Related**: `korea-ma-market-research`, `hta-dossier`
- **Future v3.0** (메모리): 3-Layer 풀 재구성 (사용 패턴 정착 시)
