# Quick Reference — 한 줄 요약

> **사용 시점**: 다른 reference 파일 view하기 전 우선 확인. 37 KR-RULE 한 줄 요약 + 5개 MSD 자산 핵심 fact + 자주 틀리는 사실.

---

## 37 KR-RULE 한 줄 요약

### Pricing (약가) — 기존
- **KR-RULE-001** — WAP 90% 신규 등재 (희귀·생물·새 기전 100%, 소아 95%)
- **KR-RULE-002** — 메인 품목 (다적응증·다인하 history) 추가 인하 한계 ⭐ Keytruda
- **KR-RULE-004** — 제네릭 산정률 53.55% → **45%** 개편 (2026)
- **KR-RULE-006** — 경평면제 트랙 (희귀·항암·국가필수의약품)
- **KR-RULE-007** — 단독품목 LOE 면제 ⭐ Zerbaxa·Emend
- **KR-RULE-008** — Bridion (sugammadex) 이미 LOE ⭐ 미래시제 금지
- **KR-RULE-009** — 첫 제네릭 출시 후 오리지널 1년 70% → 53.55% (개편 후 45%)
- **KR-RULE-028** — **약가 유연계약제** (환급제 ≠ RSA, 별도 청구) 2026 2Q ⭐
- **KR-RULE-029** — 신속등재-후평가-조정 트랙 (혁신신약 **선별** 적용, 2028~)
- **KR-RULE-030** — 적응증별 약가제 효과성 검토 (2026~)

### RSA (위험분담)
- **KR-RULE-003** — 기존 RSA 재조정 난이도 매우 높음 ⭐
- **KR-RULE-018** — RSA 4유형: 환급형 / 조건부 지속·환급 / 총액제한 / 사용량 제한
- **KR-RULE-019** — 경평면제 약제 = 총액제한형 RSA 의무
- **KR-RULE-020** — RSA 재평가 간소화 (단순환급형 + 3번째 + 변동 없음)
- **KR-RULE-021** — RSA 급여확대 비용효과성 평가 생략 (단순환급형 + 15억 미만)

### Process (절차)
- **KR-RULE-010** — 타사 자산 병용요법 일방 신청, 정부 중재
- **KR-RULE-011** — 신약 등재 총 약 300일 (심평원 120-150일 + 협상 30-60일)
- **KR-RULE-012** — 약평위 매월 첫 주 목요일, 결과 통보 +2주
- **KR-RULE-013** — 행정예고 → 고시 30일 의견수렴
- **KR-RULE-014** — 건정심 심사: 일반 서면 / 위험분담 대면
- **KR-RULE-015** — MOHW 협상명령 → 10일 내 일정 → 60일 협상
- **KR-RULE-016** — 신속등재 3경로 (병행 시범 / 허가-평가 연계 / 경평면제+RSA)
- **KR-RULE-017** — 2026 희귀질환 신속등재 240→100일

### Access
- **KR-RULE-005** — 산정특례: **암 5%, 희귀·중증난치 10%**

### Evaluation
- **KR-RULE-022** — ICER 임계값 GDP 기준 삭제 (2021~), 4요소 탄력 평가
- **KR-RULE-023** — 혁신성 인정 신약 ICER 상향 (2024~), 3요건 모두 만족 시
- **KR-RULE-024** — 항암제 5,000만원/QALY (2013 historical reference)

### Post-marketing
- **KR-RULE-025** — 사용량-약가 연동 3유형 (가/나/다), 최대 15% 인하, 30억 미만 면제
- **KR-RULE-026** — 급여확대 100억 이상 = 공단 협상으로 인하율 결정
- **KR-RULE-027** — 급여확대 표 (1.5%~5.0%) — 청구액 증가율 × 추가 청구액 교차

### 2026 개편안 — 신규 7개 ⭐⭐ (`reform_2026.md` 참조)

- **KR-RULE-031** — 기등재 의약품 11년 단계 인하 (2026~2036) ⭐⭐
  - 그룹 1: 첫 제네릭 진입 2012 이전 → 2026 시작 → 2029 (일반)/2032 (혁신형)
  - 그룹 2: 첫 제네릭 진입 2013 이후 → 2030 시작 → 2033 (일반)/2036 (혁신형)
  - **Floor rule**: 이미 도달한 약가는 추가 인하 없음
  - **한국 MSD 모든 특허만료 자산 = 그룹 2 또는 단독 면제 → 2030 이전 인하 없음** ⭐
- **KR-RULE-032** — 다품목 등재 억제 (계단식 13번째부터, 기준 미충족 80%)
- **KR-RULE-033** — 기업 유형별 약가 우대 (혁신형 60% / 준혁신형·수급안정 50%) ⭐
  - **MSD 한국법인 혁신형 인증 status 확인 시급**
- **KR-RULE-034** — 수급안정 의약품 우대 (퇴장방지 +10%, 국산원료, 직접생산, 항생주사제)
- **KR-RULE-035** — 사용량-약가 연동 면제 확대 (인상 약제 3년, 비축물자 완전)
- **KR-RULE-036** — 급여적정성 재평가 paradigm 변화 — 약가 인하로 급여 유지 옵션 사라짐. 선별급여 50/80%만
- **KR-RULE-037** — 주기적 약가 평가조정 (2027~2029 모델 → 2030 시행, 3~5년 주기)

---

## 5개 MSD 자산 핵심 fact (절대 틀리면 안 됨)

### Keytruda (pembrolizumab) ⭐ Tier 1
- **상태**: 등재 (2017-08-21), 30+ 적응증, 40+ 병용
- **약가 history**: 10년간 4회 인하, **가장 최근 2026-01** (11개 적응증 동시 확대 시)
- **추가 인하 여력**: 사실상 소진 (KR-RULE-002)
- **RSA**: 적응증별 환급형 + expenditure cap, 분리 운영
- **재조정 난이도**: very high (KR-RULE-003)
- **2026 개편 영향**: on-patent → KR-RULE-031 적용 안 됨. 단 KR-RULE-030 (적응증별 약가제) critical

### Welireg (belzutifan) ⭐ Tier 1
- **상태**: pending — **4차 신청 진행 중**
- **VHL 희귀** (RCC·CNS-HB·pNET)
- **RSA 4차 제안**: PPDT-layered soft cap (Hard Cap 대비 11년 ~233억 net 개선)
- **LITESPARK-012 (1L RCC) 실패**, LITESPARK-011 (2L+ RCC) FDA 10/4 PDUFA
- **활용 카드**: KR-RULE-006 (경평면제), KR-RULE-017 (희귀 100일), KR-RULE-023 (혁신성 ICER)

### Bridion (sugammadex) ⭐ Tier 1
- **상태**: 등재, **이미 LOE 도래**
- ⚠️ **미래시제 분석 절대 금지** (KR-RULE-008)
- **단독 공급 여부**: verification_pending
- **마취과 hospital channel** — volume erosion이 가격 인하보다 큰 risk
- **2026 개편**: 첫 제네릭 진입 시점 verification 필요. 진입 시 그룹 2 (2030+) 또는 KR-RULE-007 면제

### Zerbaxa (ceftolozane/tazobactam) ⭐ Tier 1
- **상태**: 등재 (2022-06, 항균제 경평면제 첫 사례 PREC-2022)
- **이미 LOE 도래, 단독 공급**
- **단독품목 면제** (KR-RULE-007) → generic 인하 rule 미적용
- **2026 개편**: 그룹 분류 trigger 미발생 + KR-RULE-007 이중 방어막

### Emend (aprepitant) ⭐ Tier 1
- **상태**: 등재
- **이미 LOE 도래, 단독 공급**
- **단독품목 면제** (KR-RULE-007), premium retention
- **CINV 예방** — chemotherapy supportive care
- **2026 개편**: Zerbaxa와 동일 이중 방어막. 단 국가필수의약품 지정·A8 근거 강도 차이 가능

---

## 자주 틀리는 사실 (Anti-pattern Checklist)

분석할 때 다음을 자가 검증:

| ❌ 잘못된 패턴 | ✅ 올바른 사실 |
|---------------|---------------|
| "Bridion LOE 시점에 ~될 것" (미래시제) | Bridion은 이미 LOE 도래. generic entry 실제 상태가 변수 (KR-RULE-008) |
| "저박사·에멘드도 새 산정률 45% 적용" | 단독품목이므로 KR-RULE-007 면제 |
| "Keytruda 추가 약가 인하 가능" | 1월 인하 완료, 추가 인하 여력 사실상 소진 (KR-RULE-002) |
| "기존 RSA를 outcome-based로 전환" | 5년 주기 + 담보·이자 + 신규 협상 수준 부담 (KR-RULE-003) |
| "한국 MSD 자산도 2026부터 11년 인하" ⭐ | **그룹 2 (2030+ 시작)** 또는 단독 면제 (KR-RULE-031) |
| "매년 단계 목표값까지 자동 인하" | **Floor rule** — 이미 도달했으면 추가 인하 없음 (KR-RULE-031 원칙 2) |
| "약가 유연계약 = RSA의 일종" | RSA는 **환급**, 유연계약은 **별도 청구** — 본질 다름 (KR-RULE-028 vs 018) |
| "급여적정성 재평가에서 약가 인하로 유지 가능" | 그 옵션 사라짐. **급여유지 / 제외 / 선별급여 50·80%** (KR-RULE-036) |
| "혁신신약 신속등재 모두 자동 적용" | "선별" 적용 (KR-RULE-029 정밀화) |
| "암 환자 본인부담 10%" | 암 5%, 희귀·중증난치 10% (KR-RULE-005) |
| "WAP 100% 신규 등재" | 일반 90%, 새 기전·생물·희귀 100%, 소아 95% (KR-RULE-001) |
| "ICER 임계값 1인당 GDP 기준" | 2021년 GDP 기준 삭제, 4요소 탄력 평가 (KR-RULE-022) |

---

## 4기관 역할 한 줄

| 기관 | 영문 | 핵심 |
|------|------|------|
| **MFDS (식약처)** | Ministry of Food and Drug Safety | 신약 허가, GMP, CMC |
| **HIRA (심평원)** | Health Insurance Review & Assessment | 임상유용성·경제성·RSA 평가, **약평위 (DREC)** |
| **NHIS (공단)** | National Health Insurance Service | 재정영향, **약가 + 사용량 협상** |
| **MOHW (복지부)** | Ministry of Health and Welfare | 평가 + 협상 결과 고시, **건정심 (NHPRC)** 최종 의결 |

## 8개국 (A8) reference price
미국, 영국, 일본, 독일, 프랑스, 스위스, 이탈리아, 캐나다

---

## 추가 상세 reference

| 더 자세히 알아야 할 때 | view |
|----------------------|------|
| **2026 개편 7개 신규 rule** | **`reform_2026.md`** ⭐ |
| Pricing rule 상세 | `pricing_rules.md` |
| RSA 4유형 + 재계약 detail | `rsa_rules.md` |
| 절차·일정 상세 | `process_rules.md` |
| 사후관리·ICER·산정특례 | `post_marketing.md` |
| MSD 자산별 deep dive | `msd_assets.md` |
| 제도 변천사 | `timeline_2006_2028.md` |
| 자가 검증 체크리스트 | `severe_violations.md` |
| 분석 출력 표준 | `output_standards.md` |
| **MA 전문가 시야** | **`ma_expert_lens.md`** ⭐ |
| **MSD 운영 관점** | **`msd_korea_lens.md`** ⭐ |
