# Severe Violations — 자가 검증 체크리스트

> **사용 시점**: 모든 분석 출력 직전 self-check
> **목적**: KPAD v3 Architecture에서 발견한 SEVERE VIOLATION 패턴 방지

---

## 🚨 7개 SEVERE VIOLATION 패턴 (v1.5 expanded)

### Violation #1: LOE 자산 미래시제 분석 ⚠️ 가장 자주 발생

**❌ 잘못된 패턴**:
- "Bridion compound patent 만료 후 generic entry 시점에 해당 rule이 그대로 적용될 경우..."
- "sugammadex의 LOE가 도래하면..."
- "에멘드의 특허만료 시점에..."

**✅ 올바른 패턴**:
- "Bridion은 이미 LOE 도래 상태 (KR-RULE-008). 현 시점 핵심 변수는 generic entry 실제 발생 여부와 단독 공급 상태."
- "Zerbaxa는 LOE 도래 후 단독 공급 상태에서 premium price 유지 중 (KR-RULE-007)."

**자가 검증**:
- [ ] LOE 자산 (Bridion, Zerbaxa, Emend) 언급 시 미래시제 사용했는가?
- [ ] "~할 경우", "~될 시", "~시점에" 같은 가정형 표현이 LOE 자산에 사용됐는가?
- [ ] KR-RULE-008 (Bridion 미래시제 금지) 명시 인용했는가?

---

### Violation #2: 단독품목 면제 무시 ⚠️ Zerbaxa·Emend 케이스

**❌ 잘못된 패턴**:
- "저박사도 새 산정률 45%가 적용될 것"
- "에멘드는 LOE 도래로 인하 대상"
- "MSD의 LOE 자산 모두 영향 받음"

**✅ 올바른 패턴**:
- "Zerbaxa·Emend는 시장 단독 공급 상태로 KR-RULE-007 단독품목 면제 적용 — generic 인하 rule 미적용. 단 행정예고 단서조항에서 기등재 단독품목 취급 방식 확인 필요."
- "PREC-2022-zerbaxa precedent: 항균제 경평면제 첫 등재로 premium price retention."

**자가 검증**:
- [ ] LOE 자산을 일률적으로 영향권에 넣지 않았는가?
- [ ] KR-RULE-007 단독품목 면제 cross-reference 했는가?
- [ ] 행정예고 단서조항 확인 필요성 명시했는가?

---

### Violation #3: 메인 품목 추가 인하 가능성 추정 ⚠️ Keytruda 케이스

**❌ 잘못된 패턴**:
- "Keytruda 추가 약가 인하 가능성"
- "타사 주도 병용 협상 시 Keytruda도 인하 수용 예상"
- "재정영향에 따라 Keytruda 추가 인하"

**✅ 올바른 패턴**:
- "Keytruda는 2026-01 11개 적응증 동시 확대 시 약가 인하를 이미 완료한 상태이며, 10년간 4회 누적 인하로 메인 품목 추가 인하 여력이 사실상 소진된 구조 (KR-RULE-002). 따라서 본 건 약가 추가 인하 수용은 단순 단일 협상이 아니라 portfolio-wide pricing floor 재설정 의미."
- "MSD는 협상 참여 거부 또는 최소 인하 + 병용 한정 RSA 신설 (KR-RULE-010 정부 중재) 카드를 우선 검토할 가능성."

**자가 검증**:
- [ ] Keytruda 등 다적응증 메인 품목에 추가 인하를 가벼운 옵션처럼 제시했는가?
- [ ] 2026-01 인하 history 인지하고 있는가?
- [ ] KR-RULE-002 (메인 품목 인하 한계) 명시 인용했는가?

---

### Violation #4: 기존 RSA 재조정 가벼운 옵션 제시 ⚠️ RSA 케이스

**❌ 잘못된 패턴**:
- "Outcome-based RSA로 전환 검토"
- "RSA cap 재산정 협상"
- "기존 환급률 조정 협의"

**✅ 올바른 패턴**:
- "기체결 Keytruda 적응증별 RSA 구조 재조정은 행정·계약 난이도 매우 높음 (KR-RULE-003). 재계약은 5년 주기 + 잔여 1년 미만 + 담보·이자 부담의 구조적 제약. 따라서 본 건 협상은 신규 RSA layer 추가 형식으로 설계되어야 함."
- "단순환급형 + 15억 미만 급여확대는 KR-RULE-021로 비용효과성 평가 생략 가능 — 활용 가능 케이스 식별."

**자가 검증**:
- [ ] RSA 재조정을 "검토 가능"이라며 가벼운 옵션처럼 제시했는가?
- [ ] 5년 주기 + 잔여 1년 미만 + 담보·이자 부담 인지했는가?
- [ ] KR-RULE-003 (RSA 재조정 난이도) 명시 인용했는가?
- [ ] 신규 layer 추가 vs 구조 재조정 명확히 구분했는가?

---

### Violation #5: KB 사실 무시한 일반론적 추론 ⚠️ 가장 광범위

**❌ 잘못된 패턴**:
- "약평위에서 재검토 가능"
- "한국에도 영향이 있을 것으로 보임"
- "급여 신청 시 재정영향 검토 필요"

**✅ 올바른 패턴**:
- KR-RULE 번호 명시 인용
- 7개 mechanism 중 1개 이상 구체 인용:
  - RSA 유형 (환급형/총액제한/outcome-based/utilization-based)
  - WAP 90% (또는 차등 비율)
  - Expenditure cap 총액 상한
  - 선별급여 30/50/80%
  - 경제성평가 면제 트랙
  - 4대중증 본인부담 5%
  - 행정예고 → 고시 30일 의견수렴

**자가 검증**:
- [ ] "약평위" 같은 generic 단어만 사용하지 않았는가?
- [ ] KR-RULE 번호로 mechanism 구체 인용했는가?
- [ ] 사실이 KB에 없는데 일반론으로 추정하지 않았는가?

---

### Violation #6: 그룹 분류 오류 ⭐ NEW (2026 개편안)

**❌ 잘못된 패턴**:
- "한국 MSD 자산도 2026 하반기부터 단계 인하 시작"
- "2012년 이전 등재 자산은 그룹 1"
- "Bridion 등재 시점 기준으로 그룹 분류"

**✅ 올바른 패턴**:
- "그룹 분류 기준은 등재 시점이 아닌 **동일 성분의 최초 제네릭 진입 시점** (KR-RULE-031 원칙 1)"
- "한국 MSD의 모든 특허만료 자산은 그룹 2 (2030년 이후 시작) 또는 단독품목 면제 (KR-RULE-007). 2030년 이전 본 11년 단계 인하에 의한 추가 인하 없음."
- "Bridion 첫 제네릭 진입 시점 verification 필요. 진입했다면 2013+ 시점일 것이므로 그룹 2 분류."

**자가 검증**:
- [ ] 그룹 분류 기준을 등재 시점으로 잘못 잡지 않았는가?
- [ ] 한국 MSD 자산을 그룹 1로 분류하지 않았는가?
- [ ] on-patent 자산을 본 11년 인하 적용 대상에 포함시키지 않았는가?
- [ ] KR-RULE-031 원칙 1 (그룹 분류 = 첫 제네릭 진입) 명시 인용했는가?

---

### Violation #7: Floor rule 무시 ⭐ NEW (2026 개편안)

**❌ 잘못된 패턴**:
- "2030년 51%, 2031년 49%, 2032년 47% 등 매년 자동 인하"
- "그룹 2 일반기업은 2030~2033년 사이 단계 목표값으로 매년 인하"

**✅ 올바른 패턴**:
- "Floor rule (KR-RULE-031 원칙 2)에 따라 연도별 목표값에 이미 도달한 약가는 추가 인하 없음. 즉 매년 [현재 약가 vs 연도 목표값] 비교 후 더 낮은 쪽이 유지됨."
- "예: 2030년 목표 51%인데 어떤 자산이 이미 50%면 2030년 추가 인하 없음. 2031년 목표 49%이면 49%로 인하."

**자가 검증**:
- [ ] 매년 단계 목표값 자동 적용 가정 안 했는가?
- [ ] Floor rule (이미 도달한 약가는 추가 인하 없음) 명시했는가?
- [ ] 연도별 목표값 vs 현재 약가 비교 명시했는가?
- [ ] KR-RULE-031 원칙 2 명시 인용했는가?

---

## 🔍 출력 직전 8개 self-check

분석을 publish하기 전에 다음 8개 질문에 답하라. **모두 ✅이어야 함**.

| # | 질문 | 체크 |
|---|------|------|
| 1 | LOE 자산 (Bridion·Zerbaxa·Emend) 언급 시 미래시제·가정형 표현 사용 안 했는가? | [ ] |
| 2 | 단독품목 (Zerbaxa·Emend)에 일률적 generic 인하 영향 추정 안 했는가? | [ ] |
| 3 | Keytruda 등 메인 품목에 추가 약가 인하를 가벼운 옵션처럼 제시 안 했는가? | [ ] |
| 4 | 기체결 RSA 자산에 RSA 구조 재조정을 "검토 가능"으로 가볍게 다루지 않았는가? | [ ] |
| 5 | KR-RULE 번호 1개 이상 구체 인용했는가? | [ ] |
| 6 | KB에 없는 사실을 일반론으로 추정하지 않았는가? | [ ] |
| 7 | ⭐ 그룹 분류 기준을 첫 제네릭 진입 시점으로 했는가? (등재 시점 ❌) | [ ] |
| 8 | ⭐ Floor rule 적용 (이미 도달한 약가 추가 인하 없음) 명시했는가? | [ ] |

---

## 추가 epistemic discipline

### "What this analysis does NOT claim" 섹션 추가 권장

분석 결과의 마지막에 다음 형식으로 명시:

```
## What this analysis does NOT claim
- [Bridion 구체 가격 영향 수치는 generic entry 공식 확인 전까지 산정 불가]
- [Zerbaxa·Emend 단독품목 면제가 이번 개편에서 자동 유지된다고 단정하지 않음 — 행정예고 문구 확인이 전제]
- [경쟁사 generic 공급자의 원가구조·시장 철수 가능성은 public data 추정 아닌 intelligence로만 확인]
- [2026 개편안 KR-RULE-031~037은 고시 개정 진행 중 — 단서조항 변경 가능성]
```

이렇게 모르는 것을 명시하는 것이 **senior strategist의 epistemic discipline**.

---

## 참조 우선순위

자가 검증 시 의심되면 view:

| 의심 영역 | view |
|----------|------|
| LOE·단독품목 | `pricing_rules.md` (KR-RULE-007, 008) + `msd_assets.md` (Bridion·Zerbaxa·Emend) |
| RSA 재조정 | `rsa_rules.md` (KR-RULE-003, 020, 021) |
| Keytruda 추가 인하 | `pricing_rules.md` (KR-RULE-002) + `msd_assets.md` (Keytruda) |
| **그룹 분류·Floor rule** ⭐ | **`reform_2026.md` (KR-RULE-031 원칙 1, 2)** |
| **혁신형 인증** ⭐ | `reform_2026.md` (KR-RULE-033) |
| Mechanism 구체 인용 | `quick_reference.md` (37 KR-RULE 한 줄 요약) |
| 절차·일정 | `process_rules.md` |
| 사후관리·산정특례 | `post_marketing.md` |
| **payer logic·전략 원칙** ⭐ | **`ma_expert_lens.md`** |
| **MSD 운영 관점** ⭐ | **`msd_korea_lens.md`** |
