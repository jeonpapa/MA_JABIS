# 한국 MSD 운영 관점 — Operating Lens

> **사용 시점**: 한국 MSD portfolio 또는 자산별 운영 의사결정·전략 수립 시
> **핵심**: payer logic을 이해한 후 **MSD 운영 환경의 제약·옵션·트레이드오프** 안에서 최적해 찾기
> **차별화**: 일반 MA 분석이 아닌 **MSD operations** 시야

---

## 1. 한국 MSD Portfolio 구조

### Tier 1 — 핵심 자산 (5개) ⭐
사업적 중요도·매출 기여·전략적 의미 모두 큰 자산. 본 skill의 deep dive 우선순위.

| 자산 | TA | 상태 | 핵심 운영 이슈 |
|------|-----|------|---------------|
| **Keytruda** | oncology | covered, 30+ 적응증 | 메인 품목 인하 한계 (KR-RULE-002) + 적응증별 RSA 다수 (KR-RULE-003) |
| **Welireg** | oncology rare | pending 4차 신청 | VHL 희귀, RSA 4차 PPDT-layered soft cap |
| **Bridion** | hospital acute | covered, **이미 LOE** | 미래시제 분석 금지 (KR-RULE-008), generic entry status verification |
| **Zerbaxa** | anti-infective | covered, **LOE 단독** | KR-RULE-007 단독품목 면제, 항균제 stewardship |
| **Emend** | supportive care | covered, **LOE 단독** | KR-RULE-007 면제, premium retention |

→ 상세 자산 정보는 `msd_assets.md` view.

### Tier 2 — 주요 자산 (4개)
사업적 중요도 높지만 본 skill에서는 light touch. 향후 deep dive 예정.

| 자산 | TA | 핵심 |
|------|-----|------|
| **Reblozyl** | oncology rare | MDS·β-thal, BMS 코프로모션 |
| **Gardasil 9** | vaccine | NIP 확대, 9가 유일 |
| **Vaxneuvance** | vaccine | Prevnar 20 경쟁 |
| **Prevymis** | anti-infective | CMV 예방, allo-HSCT |

### Tier 3 — 관리 자산 (8개)
정기 모니터링 대상.

Pneumovax 23, RotaTeq, MMR II, Varivax, Recarbrio, Cancidas, Noxafil, Invanz

### Pipeline (3개 핵심)
- **enlicitide** (PCSK9 oral) — Repatha/Praluent 환경 모니터링
- **sac-TMT** (TROP2 ADC)
- **V940** (mRNA personalized vaccine)

### Portfolio 차원의 운영 제약 (4가지)
1. **on-patent 비중 매우 높음** — Keytruda·Welireg·Reblozyl·Gardasil 9·Vaxneuvance·Prevymis 등
2. **LOE 단독 자산 보호 우선** — Zerbaxa·Emend의 단독 status 유지가 portfolio 방어막
3. **다국적 본사 협의 필요** — 가격·RSA 결정 시 글로벌 portfolio 영향 (precedent risk) 고려
4. **혁신형 제약기업 인증 status** — KR-RULE-033 적용 시 전체 portfolio 보호 효과

---

## 2. KR-RULE의 한국 MSD 운영 의미

각 KR-RULE이 한국 MSD에 어떻게 작동하는지 운영자 관점 재해석.

### KR-RULE-002 (메인 품목 약가 인하 한계) — Keytruda
**일반 의미**: 다적응증·다인하 history 자산은 추가 인하 여력 소진.
**운영 의미**:
- Keytruda는 2026-01 11개 적응증 동시 확대 시 인하 완료 → **2026~2027 추가 인하 협상에서 거부 또는 최소화 카드 우선**
- 타사 주도 병용 신청 시 (KR-RULE-010) **단독가 보호 + 병용 한정 신규 RSA layer** 제시
- 본사 글로벌 가격 strategy와 align 필수 (한국 인하 = 다른 국가 reference price 영향)

### KR-RULE-003 (기존 RSA 재조정 난이도) — Keytruda 적응증별 RSA
**일반 의미**: 5년 주기 + 잔여 1년 + 담보·이자 부담 → 재조정 매우 어려움.
**운영 의미**:
- Keytruda 적응증별 RSA 다수 → **portfolio-wide 재조정은 거의 불가능**
- 신규 적응증 등재 시 **기존 RSA 변경 회피 + 신규 RSA layer 추가** 형식 우선
- KR-RULE-021 (단순환급형 + 15억 미만 면제) 활용 케이스 식별 우선순위

### KR-RULE-007 (단독품목 LOE 면제) — Zerbaxa·Emend
**일반 의미**: LOE 도래해도 generic 진입 없으면 인하 면제.
**운영 의미**:
- Zerbaxa·Emend의 **단독 status 모니터링이 핵심 운영 활동**
- Generic 진입 시그널 (허가·등재·공급) 발견 시 즉시 대응 시나리오
- 행정예고 단서조항에서 **단독품목 예외 명시 여부** 매번 확인 (개편 시마다)
- KR-RULE-031 (11년 단계 인하)에 대한 이중 방어막

### KR-RULE-008 (Bridion LOE 도래) — Bridion
**일반 의미**: 이미 LOE 도래 → 미래시제 분석 절대 금지.
**운영 의미**:
- 모든 Bridion 분석은 **현재 시제** + 두 가지 verification:
  1. Generic entry 실제 발생 여부
  2. 단독 공급 status
- 마취과 hospital channel 특성: **volume erosion이 가격 인하보다 큰 risk**
- 일반명 처방 (sugammadex) 동향이 hospital pharmacy committee 차원에서 결정됨

### KR-RULE-031 (기등재 11년 단계 인하) ⭐ NEW — 모든 LOE 자산
**일반 의미**: 그룹 1/2 분류 + Floor rule.
**운영 의미** (사용자 인사이트 ⭐⭐):
- **모든 한국 MSD 특허만료 자산 = 그룹 2 또는 단독 면제**
- **2030년 이전 본 11년 인하에 의한 추가 인하 없음**
- Floor rule: 이미 도달한 약가는 추가 인하 없음 → **연도별 목표값 vs 현재 약가 비교가 매년 들어가야 함**
- 단독 자산 (Zerbaxa·Emend) → 그룹 분류 trigger 미발생 + KR-RULE-007 이중 방어
- Bridion 첫 제네릭 진입 시점 verification 필요 — 진입 시 그룹 2 분류

### KR-RULE-033 (기업 유형별 약가 우대) ⭐ NEW
**일반 의미**: 혁신형 60% / 준혁신형·수급안정 50% + 기등재 인하 시점 4년 연장.
**운영 의미**:
- **MSD 한국법인 혁신형 제약기업 인증 status 확인 시급** ⭐⭐
- 다국적 제약사가 어느 등급으로 분류되는지 (한국법인 R&D 기준 vs 본사 기준) 확인 필요
- 인증 보유 시 → 기등재 인하 시점 **2032/2036**까지 늦춤
- 사용량-약가 연동 인하율 감면 30% → 50% 상향 적용 가능

---

## 3. 자산별 전략 카드

각 Tier 1 자산이 활용 가능한 전략 옵션. *어떤 상황에서 어떤 카드를 꺼낼지*.

### 3-1. Keytruda 전략 카드

| 상황 | 카드 | KR-RULE 근거 |
|------|------|-------------|
| 타사 주도 병용 신청 | **단독가 보호 + 병용 한정 신규 RSA layer** | KR-RULE-002, 010, 018 |
| NHIS 추가 인하 압력 | **2026-01 인하 history 인용 + 추가 인하 여력 소진 논거** | KR-RULE-002 |
| 신규 적응증 확대 | **신규 RSA layer 추가** (기존 RSA 변경 회피) | KR-RULE-003, 010 |
| 소규모 적응증 (15억 미만) | **단순환급형 RSA + 비용효과성 평가 생략 활용** | KR-RULE-021 |
| 향후 적응증별 약가제 도입 | **Confidentiality 보호 카드** (40+ 적응증 portfolio 영향) | KR-RULE-030 |
| 사용량-약가 연동 발동 | **혁신형 인증 시 인하율 감면 50%** + 일시적 환급 검토 | KR-RULE-025, 033 |

### 3-2. Welireg 전략 카드

| 상황 | 카드 | KR-RULE 근거 |
|------|------|-------------|
| 4차 신청 진행 | **PPDT-layered soft cap** (Hard Cap 대비 11년 ~233억 net 개선) | KR-RULE-018, 019 |
| 경평면제 신청 | **Type A 1번째 (대체치료법 없음)** + 혁신성 3요건 | KR-RULE-006, 023 |
| 신속등재 활용 | **희귀질환 100일 트랙** (2026 시범사업) | KR-RULE-017 |
| 추가 적응증 (PPGL 등) | **단순환급형 + 15억 미만 면제** 검토 | KR-RULE-021 |
| RCC 2L+ (LITESPARK-011) | **VHL과 통합 vs 분리 RSA** 결정 | KR-RULE-018 |
| 사후 RWE 평가 | **신속등재-후평가-조정 트랙** (2028~) | KR-RULE-029 |
| 기존 산정특례 | **희귀 10% / VHL 관련 암 5% (적응증별 차등)** | KR-RULE-005 |

### 3-3. Bridion 전략 카드

| 상황 | 카드 | KR-RULE 근거 |
|------|------|-------------|
| Generic 허가 시그널 | **단독 status 즉시 verification + KR-RULE-007 면제 적용 시나리오** | KR-RULE-007, 008 |
| 일반명 처방 압력 | **Hospital pharmacy committee 차원 대응** + 안전성·편의성 evidence | KR-RULE-008 |
| Hospital tender 가격 경쟁 | **Volume retention 우선** (가격 인하 수용 vs volume 보호 trade-off) | KR-RULE-008 |
| 2026 제네릭 45% 개편 | **단독 status 시 KR-RULE-007 면제** / 진입 시 그룹 2 (2030+) | KR-RULE-004, 007, 031 |

### 3-4. Zerbaxa 전략 카드

| 상황 | 카드 | KR-RULE 근거 |
|------|------|-------------|
| 행정예고 시 | **단독품목 면제 단서조항 명시 여부 확인** | KR-RULE-007 |
| 항균제 stewardship 정책 변경 | **PREC-2022-zerbaxa 사례 인용** (경평면제 첫 등재) | KR-RULE-006 |
| Avycaz·Vabomere 적응증 확대 | **Pseudomonas 특화 + ESBL/MDR 우위 evidence** | - |
| 2026 11년 인하 | **그룹 분류 trigger 미발생 + KR-RULE-007 이중 방어** | KR-RULE-031 |

### 3-5. Emend 전략 카드

| 상황 | 카드 | KR-RULE 근거 |
|------|------|-------------|
| Generic aprepitant 허가 시그널 | **단독 status 즉시 verification** + KR-RULE-007 적용 | KR-RULE-007 |
| Akynzeo·Cinvanti 등재 | **NK-1 monotherapy vs combination 차별화** evidence | - |
| 행정예고 시 | **단독품목 면제 + 국가필수의약품 지정 여부** 확인 | KR-RULE-007, 034 |
| MASCC·ESMO 가이드라인 변경 | **KSMO 가이드라인 동기화 모니터링** | - |

---

## 4. Portfolio 차원의 운영 우선순위

### 4-1. 즉시 (2026 하반기) ⭐⭐
1. **혁신형 제약기업 인증 status 확인** (KR-RULE-033) — 가장 시급
2. **단독품목 자산 (Zerbaxa·Emend)** 행정예고 단서조항 모니터링 (KR-RULE-031, 007)
3. **약가 유연계약제 시행** 대비 (KR-RULE-028) — enlicitide 출시 전략 영향
4. **Bridion 첫 제네릭 진입 시점 verification** (KR-RULE-008, 031)
5. **Welireg 4차 신청 진행** (PPDT-layered soft cap)

### 4-2. 단기 (2027~2029)
6. **ICER 임계값 가중치** (KR-RULE-023) Welireg 4차 호재
7. **enlicitide 출시 전략** 약가 유연계약제 활용
8. **Keytruda 신규 적응증** 신규 RSA layer 형식 유지

### 4-3. 중기 (2030~2036)
9. **그룹 2 단계 인하 시작 (2030)** — 한국 MSD 자산 영향 평가
10. **주기적 약가 평가조정 시행** (KR-RULE-037)
11. **단독품목 자산** 단독 status 유지 여부 핵심
12. **KR-RULE-029 사후평가-조정 트랙** Welireg 추가 적응증·Keytruda 신규 적응증 활용

---

## 5. 본사 ↔ 한국법인 alignment 고려사항

다국적 제약사 한국법인 운영의 본질적 trade-off.

### 5-1. 가격 결정의 글로벌 영향
- 한국 약가 인하 = **다른 국가 reference price 영향**
- 특히 A8 국가군 사용국가에서 한국 약가 참조
- 본사 글로벌 가격 strategy와 매번 align 필요

### 5-2. RSA 구조 결정의 precedent risk
- 한국 RSA 구조 → 본사 차원에서 **다른 국가 협상의 precedent**
- 특히 outcome-based 측정 인프라 부재 상태에서 한국이 frontier 국가 됨
- → 본사 결정권 큼

### 5-3. 임상 evidence generation의 우선순위
- 글로벌 임상 메시지 ≠ 한국 reimbursement 메시지
- 한국 RWE generation 별도 우선순위 부여 필요
- 특히 KR-RULE-029 (신속등재-후평가-조정) 활용 시 RWE 인프라 critical

### 5-4. 의사결정 속도 차이
- HIRA 약평위 매월 첫 목요일 (KR-RULE-012) — 빠른 결정 cycle
- 본사 글로벌 의사결정 — 분기별 sync
- → 본사 사전 align 없이 한국 차원 단독 결정 어려움

---

## 6. 자산별 모니터링 항목 (priority order)

### Critical Priority (매주 확인)
- Welireg 4차 신청 status (HIRA 미팅·약평위 결과)
- Bridion 첫 제네릭 진입 시그널
- Zerbaxa·Emend 단독 status 변경 시그널
- 혁신형 제약기업 인증 status 변경

### High Priority (매월 확인)
- 약평위 매월 첫 목요일 결과 (Keytruda 신규 적응증 + 타사 주도 병용)
- 행정예고 단서조항 변경 (KR-RULE-031, 033 시행 관련)
- 사용량-약가 연동 자동 발동 (Keytruda·Gardasil 9)
- 경쟁 약물 신규 등재 (PD-1·PD-L1·NK-1·항균제)

### Medium Priority (매분기 확인)
- 보건복지부 정책 발표안 (다음 단계 정책 시그널)
- 주요국 가격 변경 (A8 reference)
- 임상 가이드라인 update (KSMO·KSR·KSID 등)
- 사후평가 결과 발표 (기등재 재평가)

---

## 7. 자가 검증 체크리스트

분석 작성 시:

- [ ] MSD 자산을 일률적 영향으로 추정하지 않았나? (on-patent / 단독 / LOE-with-generic 구분)
- [ ] 혁신형 제약기업 인증 적용 가능한 케이스 식별?
- [ ] 본사 alignment·precedent risk 고려?
- [ ] 자산별 strategic 카드 구체 인용?
- [ ] Floor rule (KR-RULE-031 원칙 2) 인지?
- [ ] 단독 status 자산의 이중 방어막 인지?
- [ ] 운영 제약 (KR-RULE-002, 003) 무시한 가벼운 추정 안 했나?

---

## 8. 다른 reference와 연결

| 더 자세히 알아야 할 때 | view |
|----------------------|------|
| Payer logic·전략 원칙 framework | `ma_expert_lens.md` |
| Tier 1 자산 deep dive | `msd_assets.md` |
| 2026 개편안 7개 micro-rules | `reform_2026.md` |
| 30개 KR-RULE 사실 base | `pricing_rules.md`, `rsa_rules.md`, `process_rules.md`, `post_marketing.md` |
| 5개 SEVERE VIOLATION | `severe_violations.md` |
| 분석 출력 표준 R1~R6 | `output_standards.md` |
