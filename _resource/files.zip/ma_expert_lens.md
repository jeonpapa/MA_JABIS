# MA 전문가 시야 — Korean Reimbursement System

> **사용 시점**: 정책·뉴스·이슈를 어떤 관점으로 읽을지 framework이 필요할 때
> **핵심**: 일반 약물 정보가 아닌 **payer decision logic 기반 분석**이 개입되는 순간 trigger
> **차별화**: Gemini/GPT의 일반론과 본 skill의 본질적 차이는 이 시야에 있음

---

## 1. 한국 약가 제도의 본질 — 5대 인식

한국 약가 제도를 정확히 분석하려면 다음 5가지 본질을 내재화해야 합니다.

### 1-1. Single payer system의 협상력
- 한국은 **단일 보험자 (NHIS)** 구조 → 정부가 단독 buyer
- 미국 (multi-payer + PBM 협상) 또는 일본 (행정고시 단가) 과 본질적으로 다름
- **결과**: 정부 협상력이 극단적으로 강함. 회사가 가질 수 있는 leverage는 "철수 위협" 또는 "근거 부재" 둘 중 하나.
- **MA 전략 시사점**: 협상에서 이기려는 시도보다 **payer가 받아들일 수 있는 구조**를 먼저 설계하는 게 효율적.

### 1-2. 정부 = 4기관 분권 구조
한국 약가 의사결정은 **단일 기관이 아닌 4기관 분권 구조**:

| 기관 | 결정 영역 | 주요 의사결정 시그널 |
|------|----------|---------------------|
| **MFDS (식약처)** | 허가 | 안전성·유효성 + GMP·CMC |
| **HIRA (심평원)** | 임상유용성·경제성·RSA 평가 | 약평위(DREC) 매월 첫 목요일 |
| **NHIS (공단)** | 약가·사용량 협상 | 협상명령 후 60일 |
| **MOHW (복지부)** | 최종 의결·고시 | 건정심 |

각 기관의 의사결정 시그널이 다름. **HIRA 약평위 결과 ≠ 최종 결정**임을 항상 인지해야 함.

### 1-3. 선별등재제도 (Positive List) 의 의미
- 2007년 도입 이후 **임상유용성 + 경제성 모두 입증해야 급여**
- 즉 *"안전한 약 = 자동 급여"* 가 아님
- **회사가 입증 책임 (burden of proof)을 짊**

### 1-4. "재정중립" 기조의 의미
- 한국은 GDP 대비 의약품비 OECD 평균 이상
- 정부의 모든 신약 수용은 **다른 약가 인하로 funding** 필요 (재정중립)
- 따라서 **신약 등재 = 다른 자산 인하 압력** 의 양면

### 1-5. "코리아 패싱" 정책 트라우마
- 2010년대 후반 글로벌 신약의 한국 출시 지연·미출시 사례 누적
- 정부 정책 방향이 *"엄격한 가격 통제"* 에서 *"접근성 + 적정가격 + 글로벌 진출 지원"* 의 균형으로 변화 중
- 2014년 RSA 도입, 2015년 경평면제, 2024년 ICER 상향, 2026년 신속등재 모두 같은 narrative
- **MA 전략 시사점**: 정부도 코리아 패싱 회피하려는 inner motivation 있음 → 활용 가능

---

## 2. HIRA 의사결정 logic — 분석할 때 무엇을 봐야 하는가

### 2-1. 약평위(DREC) 의사결정의 5가지 핵심 변수

뉴스·이슈가 약평위 결정에 영향을 미치는지 판단하려면 다음 5가지 lens로 봐야 합니다:

| Lens | 핵심 질문 | 분석 방법 |
|------|----------|----------|
| **Clinical** | 비교약제 대비 임상적 유용성 개선이 있는가? | 우월·비열등·삶의 질 개선 어느 트랙? |
| **Patient** | 대상 환자가 명확하고 정량화되는가? | 환자수 추정 + Sub-population 정의 |
| **Comparator** | 비교약제 선정이 정당한가? | WAP 산출 기반 + 가장 많이 쓰이는 약 |
| **Cost-effectiveness** | ICER 또는 WAP 수용 가능한가? | 경평·경평면제·CMA 트랙 결정 |
| **Budget impact** | 5년 재정영향이 감당 가능한가? | BIA + 사용량-약가 연동 trigger |

### 2-2. 5개 sub-committee의 역할 차이

| Sub-committee | 결정 영역 | 시그널 |
|--------------|---------|--------|
| **RCC** (급여기준 소위) | 급여 여부 + 급여 기준 | 학회 의견 + 임상 가이드라인 |
| **PEC** (경평 소위) | 경제성평가 모형 + 가정 | ICER 임계값 적용 + 비교약제 |
| **BIAC** (재정영향 소위) | 5년 BIA 검증 | 사용량 가정 + 인구 추정 |
| **RSAC** (위험분담 소위) | RSA 유형 + 구조 | 4유형 중 적합 + cap 산정 |
| **DREC** (약평위) | 종합 결정 | 위 4개 위원회 결과 + 부가 검토 |

### 2-3. 약평위 결정 분석 시 필수 체크
- **회사 수용 여부**: 결정 → 회사 수용 시 협상 명령. 거부 시 재평가 cycle.
- **부속 합의 조건**: 안정적 공급 + 사용량 협상 (KR-RULE-015)
- **건정심 심사 방식**: RSA 약제는 대면 심사 (KR-RULE-014)

---

## 3. 5대 전략 원칙 — 모든 분석에 공통

userPreferences에 명시된 핵심 원칙들. 모든 분석은 이 5가지 원칙을 따라야 함.

### 3-1. Population refinement over expansion ⭐
**"환자 수는 과대 추정하지 말고, 좁고 방어 가능한 정의로 재구성"**

- 일반적 회사 본능: 시장 크게 → 매출 크게
- 한국 reimbursement의 본능: 시장 크게 = 재정영향 크게 = 급여 어려움
- **올바른 접근**: 명확한 sub-population 정의 + 정량적 unduplicated 산출
  - 예: Welireg → VHL 전체가 아닌 surgical ineligibility criteria 적용한 환자만

### 3-2. Uncertainty reduction ⭐
**"효능을 강조하는 것보다 재정·임상 리스크를 구조화해 차단하는 것이 우선"**

- Payer는 효능 의심하지 않음. **재정 폭주 + 임상 효과 미확인 + 사후 회수 불가**가 진짜 두려움.
- 따라서 RSA·BIA·후속 평가 등 **리스크 구조화 도구**가 클리닉컬 메시지보다 효과적
- **올바른 접근**: 모든 incremental risk에 대해 *"이 risk를 어떤 mechanism으로 차단할 것인가"* 답을 제공

### 3-3. Clinical → Reimbursement translation ⭐
**"OS / PFS / PRO 등 endpoint를 HIRA가 인정하는 언어로 재해석"**

- 글로벌 임상 메시지 ≠ 한국 reimbursement 메시지
- HIRA가 인정하는 endpoint 위계: OS > PFS > ORR > PRO > biomarker
- **올바른 접근**: clinical evidence를 KR-RULE 인용 가능한 형식으로 번역
  - 예: "PFS 6개월 우월" → "WAP-비열등 + 편의성 개선" 트랙으로 재구성

### 3-4. Quantification ⭐
**"모든 주장은 정량화 — %, 환자 수, 원화 금액, 연도별 시뮬레이션"**

- "환자 접근성 개선" 같은 정성 표현은 분석에서 금지
- 모든 주장은 R1 numerical_check를 동반
  - "재정영향 ~120억" / "환자수 ~2,400명" / "BIA Year 5 ~340억"

### 3-5. Actionable strategy ⭐
**"분석에서 멈추지 말고 반드시 실행 가능한 다음 액션으로 종결"**

- "주의 필요" 같은 vague 결론 금지
- R2 scenario branching으로 2개 분기 + 각 분기에 구체 액션
  - Scenario A 시: 액션 Alpha + 책임자 + 시한
  - Scenario B 시: 액션 Beta + 책임자 + 시한

---

## 4. 정책 신호 해석법

뉴스·자료에서 무엇을 읽어야 하는지.

### 4-1. 정부 자료의 4단계 신뢰도

| 단계 | 의미 | 분석 자세 |
|------|------|----------|
| **법령** (국민건강보험법 등) | 변경 어려움 | 변경되면 paradigm shift |
| **고시** (보건복지부 고시) | 본격 효력 | 행정예고 → 시행 |
| **지침·세부평가기준** (HIRA 내부) | 운영 재량 | 자주 update, 핵심 포인트 |
| **보도자료·발표안** | 의도 표명 | **확정 아님** — 변경 가능성 항상 명시 |

### 4-2. 정책 발표 5단계 흐름

```
1단계: 정책 연구 (1~2년 전)
  ↓
2단계: 발표안 / 개편안 (입법예고 전)
  ↓
3단계: 입법예고 (60일 의견수렴)
  ↓
4단계: 건정심 의결
  ↓
5단계: 행정예고 (30일) → 고시 시행
```

각 단계에서 **수정 가능성**이 다름:
- 1~2단계: 큰 폭 변동 가능. **확정 사실 분석 금지**
- 3~4단계: 단서조항·예외 변경 가능
- 5단계: 거의 확정. 단 단서조항·예외 마지막 변경 있을 수 있음

### 4-3. 뉴스 분류 — 4가지 신호

| 분류 | Trigger | MA 분석 깊이 |
|------|---------|-------------|
| **Direct** | 6개월 내 자산의 구체적·측정 가능한 변화 | 5~8 문장 + R1·R2·R3 모두 |
| **Indirect** | precedent·benchmark 작용 (구체 mechanism 필수) | 3~5 문장 |
| **Monitor** | 산업 일반 시그널·long-term trend | 2~4 문장 |
| **Opinion piece** | 사설·칼럼·기고 (R4 trigger) | 2~3 문장 |

⚠️ "영향이 있을 것으로 보임" 만으로 indirect 분류 금지.

### 4-4. Opinion piece 처리 5개 signal
다음 2개 이상 충족 시 Opinion Piece로 분류:
- 헤드라인 [사설]·[칼럼]·[View]·[기고]
- prescriptive 문장 ("~해야 한다") 다수
- 저자 외부 논객
- 1차 source 부재
- 정책 제안 나열

처리 시: classification = monitor 강제, confidence = low 강제, ma_insight 2~3 문장 제한.

---

## 5. 분석 framework — Clinical → Patient → Market → Access → Pricing → Execution

**6-step 흐름**:

```
1. Clinical Evidence
   - 임상시험·RWE·peer-reviewed 데이터
   - 한국 acceptable endpoint로 번역
        ↓
2. Patient Definition
   - Unduplicated 환자수
   - Sub-population refinement
   - Surgical/clinical ineligibility criteria
        ↓
3. Market Implication
   - 비교약제 (WAP-defining)
   - 경쟁 환경 (Direct + Adjacent)
   - 5년 BIA 시나리오
        ↓
4. Access Strategy
   - HIRA Pathway 결정 (경평·경평면제·WAP·진료상필수)
   - RSA 유형 결정 (KR-RULE-018)
   - 신속등재 활용 (KR-RULE-016, 017)
        ↓
5. Pricing Architecture
   - Floor price (외국 약가 참조)
   - Ceiling (대체약제 가격 + WAP)
   - RSA structure (환급률·cap·기간)
        ↓
6. Execution Roadmap
   - 약평위 일정 backward planning
   - Stakeholder mapping
   - 시나리오별 Plan A/B
```

**핵심**: 1~6단계 중 단계 건너뛰면 분석 부정확. 특히 2단계(Patient)와 4단계(Access) 누락이 가장 빈번한 오류.

---

## 6. 분석 시 자주 빠지는 함정 — Anti-patterns

| 함정 | 잘못된 결과 | 올바른 자세 |
|------|------------|------------|
| **글로벌 임상 메시지 그대로 사용** | HIRA 비공감 | 한국 acceptable endpoint로 번역 |
| **시장 크게 잡으면 좋다 본능** | 재정영향 = 급여 거부 trigger | Population refinement |
| **정부 정책 방향 비판** | 분석가의 자격 상실 | 정책 logic 안에서 옵션 찾기 |
| **확정 안 된 정책을 fact 처럼** | 분석 신뢰도 손상 | "고시 진행 중" 명시 |
| **단일 정책으로 dominant 결론** | 다른 layer 무시 | 사용량연동·기등재재평가·주기평가 동시 작동 |
| **MSD 자산 = 영향 받음 가정** | 단독·on-patent 자산 잘못 분류 | KR-RULE-007 면제·on-patent 우선 확인 |
| **확정형 표현 사용** ("반드시", "분명히") | epistemic 손상 | hedging 표현 ("~로 보임", "가능성") |

---

## 7. 분석 출력 시 명심할 것

### 7-1. "What this analysis does NOT claim" 섹션
모르는 것을 명시하는 게 senior strategist의 epistemic discipline.

```
## What this analysis does NOT claim
- [verification 필요한 사항 1]
- [확정 안 된 정책 사항 2]
- [단정 안 하는 추정 3]
```

### 7-2. KR-RULE 인용 우선
"약평위에서 검토 가능" 같은 generic 표현 금지. **항상 KR-RULE-XXX 번호로 구체 인용**.

### 7-3. 7개 mechanism 중 1개 이상 구체 인용
- RSA 유형 (환급형/총액제한/outcome-based/utilization-based)
- WAP 90% (또는 차등 비율)
- Expenditure cap
- 선별급여 30/50/80%
- 경제성평가 면제 트랙
- 4대중증 본인부담 5%
- 행정예고 → 고시 30일 의견수렴

### 7-4. 가치판단 형용사 금지
- 금지: "획기적", "혁신적", "놀라운", "엄청난"
- 허용: "유의미한", "주목할 만한", "구조적으로 중요한"

### 7-5. 의사결정권자 비판 금지
HIRA·MOHW·NICE 등의 결정에 대해 옳고 그름 판단 금지. 분석은 그 결정 안에서 옵션 찾기.

---

## 8. 다른 reference와 연결

| 더 자세히 알아야 할 때 | view |
|----------------------|------|
| MSD 운영 관점에서 보기 | `msd_korea_lens.md` |
| 30+개 micro-rules 사실 base | `pricing_rules.md`, `rsa_rules.md`, `process_rules.md`, `post_marketing.md`, `reform_2026.md` |
| 5개 SEVERE VIOLATION 자가 검증 | `severe_violations.md` |
| 출력 표준 (R1~R6) | `output_standards.md` |
| 빠른 사실 lookup | `quick_reference.md` |
