import { useState } from 'react';
import { keywordCloudData, brandTrafficData } from '@/mocks/dashboardData';

type BrandItem = typeof brandTrafficData[0];

const TAG_COLORS: Record<string, string> = {
  '급여': 'bg-emerald-400/10 text-emerald-400 border border-emerald-400/20',
  '약가': 'bg-red-400/10 text-red-400 border border-red-400/20',
  '허가': 'bg-amber-400/10 text-amber-400 border border-amber-400/20',
  '임상': 'bg-violet-400/10 text-violet-400 border border-violet-400/20',
  '시장': 'bg-[#00E5CC]/10 text-[#00E5CC] border border-[#00E5CC]/20',
  '매출': 'bg-sky-400/10 text-sky-400 border border-sky-400/20',
};

const getHeatColor = (trafficIndex: number, maxTraffic: number): string => {
  const ratio = trafficIndex / maxTraffic;
  if (ratio >= 0.9) return '#FF3B3B';
  if (ratio >= 0.7) return '#FF7A00';
  if (ratio >= 0.5) return '#F59E0B';
  if (ratio >= 0.3) return '#00E5CC';
  return '#6B7280';
};

const getHeatClass = (trafficIndex: number, maxTraffic: number): string => {
  const ratio = trafficIndex / maxTraffic;
  if (ratio >= 0.9) return 'text-[#FF3B3B]';
  if (ratio >= 0.7) return 'text-[#FF7A00]';
  if (ratio >= 0.5) return 'text-[#F59E0B]';
  if (ratio >= 0.3) return 'text-[#00E5CC]';
  return 'text-[#6B7280]';
};

// ── Sparkline SVG 미니 차트 컴포넌트 ──────────────────────────────────────────
interface SparklineProps {
  data: number[];
  color: string;
  width?: number;
  height?: number;
  isSelected?: boolean;
}

function Sparkline({ data, color, width = 52, height = 20, isSelected = false }: SparklineProps) {
  if (!data || data.length < 2) return null;

  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max - min || 1;

  const padX = 1;
  const padY = 2;
  const innerW = width - padX * 2;
  const innerH = height - padY * 2;

  const points = data.map((v, i) => {
    const x = padX + (i / (data.length - 1)) * innerW;
    const y = padY + innerH - ((v - min) / range) * innerH;
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  });

  const polyline = points.join(' ');

  // 마지막 점 좌표
  const lastPt = points[points.length - 1].split(',');
  const lastX = parseFloat(lastPt[0]);
  const lastY = parseFloat(lastPt[1]);

  // 면적 채우기용 polygon
  const firstPt = points[0].split(',');
  const firstX = parseFloat(firstPt[0]);
  const bottomY = padY + innerH;
  const areaPoints = `${firstX},${bottomY} ${polyline} ${lastX},${bottomY}`;

  const isUp = data[data.length - 1] >= data[0];
  const lineColor = isSelected ? color : isUp ? color : '#EF4444';
  const areaOpacity = isSelected ? 0.18 : 0.08;

  return (
    <svg
      width={width}
      height={height}
      viewBox={`0 0 ${width} ${height}`}
      className="flex-shrink-0"
      style={{ overflow: 'visible' }}
    >
      {/* 면적 채우기 */}
      <polygon
        points={areaPoints}
        fill={lineColor}
        opacity={areaOpacity}
      />
      {/* 라인 */}
      <polyline
        points={polyline}
        fill="none"
        stroke={lineColor}
        strokeWidth={isSelected ? 1.8 : 1.4}
        strokeLinejoin="round"
        strokeLinecap="round"
        opacity={isSelected ? 1 : 0.85}
      />
      {/* 마지막 점 강조 */}
      <circle
        cx={lastX}
        cy={lastY}
        r={isSelected ? 2.2 : 1.8}
        fill={lineColor}
        opacity={isSelected ? 1 : 0.9}
      />
      {isSelected && (
        <circle
          cx={lastX}
          cy={lastY}
          r={4}
          fill={lineColor}
          opacity={0.2}
        />
      )}
    </svg>
  );
}

export default function KeywordCloud() {
  const [selectedBrand, setSelectedBrand] = useState<BrandItem | null>(null);
  const maxWeight = Math.max(...keywordCloudData.map(k => k.weight));
  const maxTraffic = Math.max(...brandTrafficData.map(b => b.trafficIndex));

  const getCloudStyle = (weight: number) => {
    const ratio = weight / maxWeight;
    if (ratio >= 0.9) return { size: 'text-[22px] font-black', opacity: 1.0 };
    if (ratio >= 0.78) return { size: 'text-lg font-bold', opacity: 0.95 };
    if (ratio >= 0.65) return { size: 'text-base font-bold', opacity: 0.88 };
    if (ratio >= 0.52) return { size: 'text-sm font-semibold', opacity: 0.78 };
    if (ratio >= 0.42) return { size: 'text-[13px] font-medium', opacity: 0.65 };
    return { size: 'text-xs font-normal', opacity: 0.5 };
  };

  const top1 = brandTrafficData[0];

  return (
    <div className="bg-[#161B27] rounded-2xl border border-[#1E2530] overflow-hidden">
      {/* Header */}
      <div className="flex items-center gap-2 px-5 pt-4 pb-3 border-b border-[#1E2530]">
        <span className="w-5 h-5 flex items-center justify-center">
          <i className="ri-cloud-line text-[#00E5CC] text-base"></i>
        </span>
        <h3 className="text-white font-bold text-sm">미디어 인텔리전스</h3>
        <div className="flex items-center gap-1.5 ml-3 bg-[#FF3B3B]/10 border border-[#FF3B3B]/20 rounded-full px-2.5 py-0.5">
          <span className="w-3 h-3 flex items-center justify-center text-[#FF3B3B]"><i className="ri-fire-fill text-xs"></i></span>
          <span className="text-[#FF3B3B] text-xs font-semibold">HOT</span>
          <span className="text-[#FF3B3B] text-xs font-bold">{top1.brand}</span>
          <span className="text-[#FF7A00]/70 text-xs">{top1.company}</span>
        </div>
        <span className="ml-auto text-[#4A5568] text-xs">지난 7일 기준</span>
      </div>

      <div className="grid grid-cols-5">
        {/* ── 왼쪽: 정부 키워드 클라우드 ── */}
        <div className="col-span-2 px-5 py-5 border-r border-[#1E2530] relative overflow-hidden">
          <div className="absolute inset-0 pointer-events-none">
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 rounded-full bg-[#00E5CC]/3 blur-3xl"></div>
          </div>

          <div className="flex items-center gap-2 mb-4 relative z-10">
            <span className="w-4 h-4 flex items-center justify-center text-[#8B9BB4]">
              <i className="ri-government-line text-xs"></i>
            </span>
            <p className="text-[#8B9BB4] text-xs font-semibold">정부 기관 키워드</p>
            <span className="text-[#2A3545] text-xs">보건복지부 · 건보공단 · 심평원</span>
          </div>

          <div className="relative z-10 flex flex-wrap gap-x-3 gap-y-2 items-center justify-center min-h-[180px] content-center px-2">
            {keywordCloudData.map((kw, idx) => {
              const style = getCloudStyle(kw.weight);
              const isTop = kw.weight >= 80;
              return (
                <span
                  key={idx}
                  className={`${style.size} whitespace-nowrap leading-tight cursor-default select-none transition-all duration-200 hover:scale-110 hover:brightness-125`}
                  style={{
                    color: kw.color,
                    opacity: style.opacity,
                    textShadow: isTop ? `0 0 12px ${kw.color}60` : 'none',
                    letterSpacing: kw.weight >= 85 ? '-0.01em' : 'normal',
                  }}
                >
                  {kw.text}
                </span>
              );
            })}
          </div>
        </div>

        {/* ── 오른쪽: 브랜드 트래픽 Top 10 ── */}
        <div className="col-span-3 flex flex-col">
          <div className="flex items-center gap-2 px-5 py-3 border-b border-[#1E2530]">
            <span className="w-4 h-4 flex items-center justify-center text-[#F59E0B]">
              <i className="ri-fire-line text-xs"></i>
            </span>
            <p className="text-[#8B9BB4] text-xs font-semibold">브랜드 언급 Top 10</p>
            <span className="text-[#2A3545] text-xs">미디어 트래픽 지수 기준</span>
            <span className="ml-auto flex items-center gap-1 text-[#4A5568] text-xs">
              <i className="ri-pulse-line text-xs"></i>
              주간 추이 포함
            </span>
          </div>

          <div className="grid grid-cols-2 divide-x divide-[#1E2530]">
            {/* Brand List */}
            <div className="py-1">
              {brandTrafficData.map((brand) => {
                const heatColor = getHeatColor(brand.trafficIndex, maxTraffic);
                const isSelected = selectedBrand?.rank === brand.rank;
                return (
                  <button
                    key={brand.rank}
                    onClick={() => setSelectedBrand(isSelected ? null : brand)}
                    className={`w-full flex items-center gap-2 px-3 py-1.5 transition-all cursor-pointer text-left group ${
                      isSelected ? 'bg-[#1E2530]' : 'hover:bg-[#1E2530]/50'
                    }`}
                  >
                    {/* Rank badge */}
                    <span
                      className="text-xs font-black w-4 flex-shrink-0 text-center"
                      style={{ color: brand.rank <= 3 ? '#F59E0B' : '#4A5568' }}
                    >
                      {brand.rank}
                    </span>

                    {/* Color dot */}
                    <span
                      className="w-1.5 h-1.5 rounded-full flex-shrink-0"
                      style={{
                        backgroundColor: brand.color,
                        boxShadow: isSelected ? `0 0 6px ${brand.color}80` : 'none',
                      }}
                    ></span>

                    {/* Brand name + traffic bar */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1 mb-0.5">
                        <span className={`text-xs font-bold truncate transition-colors ${isSelected ? 'text-white' : 'text-[#C9D1D9] group-hover:text-white'}`}>
                          {brand.brand}
                        </span>
                        {brand.rank <= 3 && (
                          <i className="ri-fire-fill text-[#F59E0B] text-xs flex-shrink-0"></i>
                        )}
                      </div>
                      {/* Traffic bar */}
                      <div className="flex items-center gap-1">
                        <div className="flex-1 h-0.5 bg-[#0D1117] rounded-full overflow-hidden">
                          <div
                            className="h-full rounded-full transition-all duration-700"
                            style={{
                              width: `${Math.round((brand.trafficIndex / maxTraffic) * 100)}%`,
                              backgroundColor: heatColor,
                            }}
                          ></div>
                        </div>
                        <span
                          className={`text-[10px] font-bold flex-shrink-0 tabular-nums ${getHeatClass(brand.trafficIndex, maxTraffic)}`}
                        >
                          {brand.trafficIndex.toLocaleString()}
                        </span>
                      </div>
                    </div>

                    {/* ── 스파크라인 미니 차트 ── */}
                    <div className="flex-shrink-0 flex items-center">
                      <Sparkline
                        data={brand.sparkline}
                        color={brand.color}
                        width={52}
                        height={20}
                        isSelected={isSelected}
                      />
                    </div>

                    {/* Change % */}
                    <span className={`text-[10px] font-semibold flex-shrink-0 whitespace-nowrap ${brand.change >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                      {brand.change >= 0 ? '+' : ''}{brand.change}%
                    </span>

                    {/* Chevron */}
                    <span className={`w-3 h-3 flex items-center justify-center flex-shrink-0 transition-all duration-200 ${isSelected ? 'text-[#00E5CC] rotate-90' : 'text-[#2A3545] group-hover:text-[#8B9BB4]'}`}>
                      <i className="ri-arrow-right-s-line text-sm"></i>
                    </span>
                  </button>
                );
              })}
            </div>

            {/* News Panel */}
            <div className="flex flex-col min-h-0">
              {selectedBrand ? (
                <div className="flex flex-col h-full">
                  {/* News Header */}
                  <div className="flex items-center gap-2 px-4 py-2.5 border-b border-[#1E2530] bg-[#0D1117]/30">
                    <span className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ backgroundColor: selectedBrand.color, boxShadow: `0 0 6px ${selectedBrand.color}80` }}></span>
                    <span className="text-white text-xs font-bold">{selectedBrand.brand}</span>
                    <span className="text-[#4A5568] text-xs">·</span>
                    <span className="text-[#8B9BB4] text-xs">{selectedBrand.company}</span>
                    <span className="text-[#4A5568] text-xs">·</span>
                    <span className="text-[#4A5568] text-xs">{selectedBrand.category}</span>
                    <button
                      onClick={() => setSelectedBrand(null)}
                      className="ml-auto w-5 h-5 flex items-center justify-center text-[#4A5568] hover:text-white cursor-pointer transition-colors rounded"
                    >
                      <i className="ri-close-line text-sm"></i>
                    </button>
                  </div>

                  {/* Traffic Summary + Sparkline */}
                  <div className="flex items-center gap-3 px-4 py-2.5 border-b border-[#1E2530] bg-[#0D1117]/20">
                    <div className="flex items-center gap-1.5">
                      <i className="ri-bar-chart-2-line text-[#F59E0B] text-xs"></i>
                      <span className="text-[#8B9BB4] text-xs">트래픽</span>
                      <span className={`text-xs font-bold tabular-nums ${getHeatClass(selectedBrand.trafficIndex, maxTraffic)}`}>
                        {selectedBrand.trafficIndex.toLocaleString()}
                      </span>
                    </div>
                    <span className="text-[#1E2530]">|</span>
                    <span className={`text-xs font-semibold ${selectedBrand.change >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                      {selectedBrand.change >= 0 ? '▲' : '▼'} {Math.abs(selectedBrand.change)}%
                    </span>
                    <span className="text-[#4A5568] text-xs">전주 대비</span>

                    {/* 패널 내 스파크라인 (더 크게) */}
                    <div className="ml-auto flex items-center gap-2">
                      <span className="text-[#4A5568] text-[10px]">7주 추이</span>
                      <Sparkline
                        data={selectedBrand.sparkline}
                        color={selectedBrand.color}
                        width={72}
                        height={24}
                        isSelected
                      />
                    </div>
                  </div>

                  {/* 주간 스파크라인 상세 레이블 */}
                  <div className="flex items-center gap-1 px-4 py-1.5 border-b border-[#1E2530]/50 bg-[#0D1117]/10">
                    {selectedBrand.sparkline.map((val, idx) => {
                      const isLast = idx === selectedBrand.sparkline.length - 1;
                      const weekLabel = idx === 0 ? '-6W' : idx === 1 ? '-5W' : idx === 2 ? '-4W' : idx === 3 ? '-3W' : idx === 4 ? '-2W' : idx === 5 ? '-1W' : 'NOW';
                      return (
                        <div key={idx} className={`flex-1 text-center ${isLast ? 'opacity-100' : 'opacity-60'}`}>
                          <div className={`text-[9px] font-medium ${isLast ? 'text-[#8B9BB4]' : 'text-[#4A5568]'}`}>{weekLabel}</div>
                          <div
                            className="text-[9px] font-bold tabular-nums"
                            style={{ color: isLast ? selectedBrand.color : '#4A5568' }}
                          >
                            {(val / 1000).toFixed(1)}K
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* News List */}
                  <div className="flex-1 overflow-y-auto">
                    {selectedBrand.news.map((article, idx) => (
                      <a
                        key={idx}
                        href={article.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-start gap-2.5 px-4 py-3 border-b border-[#1E2530] last:border-0 hover:bg-[#1E2530]/50 transition-colors cursor-pointer group"
                      >
                        <span className={`text-xs px-1.5 py-0.5 rounded font-semibold flex-shrink-0 mt-0.5 ${TAG_COLORS[article.tag] || 'bg-[#4A5568]/20 text-[#8B9BB4]'}`}>
                          {article.tag}
                        </span>
                        <div className="flex-1 min-w-0">
                          <p className="text-[#C9D1D9] text-xs leading-snug group-hover:text-white transition-colors line-clamp-2 mb-1">
                            {article.title}
                          </p>
                          <div className="flex items-center gap-1.5">
                            <span className="text-[#4A5568] text-xs">{article.source}</span>
                            <span className="text-[#2A3545] text-xs">·</span>
                            <span className="text-[#4A5568] text-xs">{article.date}</span>
                          </div>
                        </div>
                        <span className="w-4 h-4 flex items-center justify-center text-[#2A3545] group-hover:text-[#00E5CC] transition-colors flex-shrink-0 mt-0.5">
                          <i className="ri-external-link-line text-xs"></i>
                        </span>
                      </a>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="flex flex-col h-full">
                  {/* 전체 스파크라인 미리보기 패널 */}
                  <div className="px-4 py-3 border-b border-[#1E2530]">
                    <p className="text-[#4A5568] text-[10px] mb-2 font-medium">7주 트래픽 추이 미리보기</p>
                    <div className="space-y-1.5">
                      {brandTrafficData.slice(0, 5).map((brand) => (
                        <div key={brand.rank} className="flex items-center gap-2">
                          <span className="text-[10px] text-[#4A5568] w-3 text-right">{brand.rank}</span>
                          <span
                            className="w-1.5 h-1.5 rounded-full flex-shrink-0"
                            style={{ backgroundColor: brand.color }}
                          ></span>
                          <span className="text-[10px] text-[#6B7280] w-16 truncate">{brand.brand}</span>
                          <Sparkline
                            data={brand.sparkline}
                            color={brand.color}
                            width={60}
                            height={16}
                          />
                          <span
                            className="text-[10px] font-semibold ml-auto whitespace-nowrap"
                            style={{ color: brand.change >= 0 ? '#34D399' : '#F87171' }}
                          >
                            {brand.change >= 0 ? '+' : ''}{brand.change}%
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="flex flex-col items-center justify-center flex-1 py-8 px-4 text-center">
                    <div className="w-10 h-10 rounded-xl bg-[#1E2530] flex items-center justify-center mb-3">
                      <i className="ri-newspaper-line text-[#2A3545] text-xl"></i>
                    </div>
                    <p className="text-[#4A5568] text-xs leading-relaxed">
                      브랜드를 클릭하면<br />관련 뉴스 원문을 확인할 수 있습니다
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
