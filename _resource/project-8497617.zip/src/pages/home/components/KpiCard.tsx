interface KpiCardProps {
  label: string;
  value: string;
  unit: string;
  change: string;
  changeType: 'up' | 'down' | 'neutral';
  description: string;
  accentColor?: string;
}

export default function KpiCard({ label, value, unit, change, changeType, description, accentColor = '#00E5CC' }: KpiCardProps) {
  const changeColor = changeType === 'up' ? 'text-emerald-400 bg-emerald-400/10' : changeType === 'down' ? 'text-red-400 bg-red-400/10' : 'text-gray-400 bg-gray-400/10';
  const changeIcon = changeType === 'up' ? 'ri-arrow-up-s-line' : changeType === 'down' ? 'ri-arrow-down-s-line' : 'ri-subtract-line';

  return (
    <div className="bg-[#161B27] rounded-2xl p-6 border border-[#1E2530] hover:border-[#2A3545] transition-all duration-200">
      <p className="text-[#8B9BB4] text-xs font-semibold uppercase tracking-wider mb-3">{label}</p>
      <div className="flex items-end gap-2 mb-2">
        <span className="text-3xl font-bold" style={{ color: accentColor }}>{value}</span>
        {unit && <span className="text-[#8B9BB4] text-sm mb-1">{unit}</span>}
        <span className={`ml-auto flex items-center gap-0.5 text-xs font-semibold px-2 py-1 rounded-full whitespace-nowrap ${changeColor}`}>
          <i className={`${changeIcon} text-sm`}></i>
          {change}
        </span>
      </div>
      <p className="text-[#8B9BB4] text-xs">{description}</p>
    </div>
  );
}
