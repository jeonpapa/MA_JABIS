import { useState } from 'react';
import { msdReimbursedDrugs, msdPipelineData } from '@/mocks/dashboardData';

const CURRENT_YEAR = 2026;

export default function MsdSummaryCards() {
  const [showKeytrudaDetail, setShowKeytrudaDetail] = useState(false);
  const [showPipelineDetail, setShowPipelineDetail] = useState(false);
  const [pipelineYear, setPipelineYear] = useState<number | null>(null);

  const currentPipeline = msdPipelineData.filter(p => p.status === 'current');

  // 올해 / 올해+1 / 올해+2 분류
  const year0 = msdPipelineData.filter(p => p.expectedYear === CURRENT_YEAR);
  const year1 = msdPipelineData.filter(p => p.expectedYear === CURRENT_YEAR + 1);
  const year2 = msdPipelineData.filter(p => p.expectedYear === CURRENT_YEAR + 2);

  const yearGroups = [
    { year: CURRENT_YEAR, label: `${CURRENT_YEAR}년`, sublabel: '올해', items: year0, color: '#00E5CC' },
    { year: CURRENT_YEAR + 1, label: `${CURRENT_YEAR + 1}년`, sublabel: '+1년', items: year1, color: '#F59E0B' },
    { year: CURRENT_YEAR + 2, label: `${CURRENT_YEAR + 2}년`, sublabel: '+2년', items: year2, color: '#7C3AED' },
  ];

  const selectedYearGroup = yearGroups.find(g => g.year === pipelineYear);

  return (
    <div className="grid grid-cols-3 gap-4">
      {/* 한국MSD 급여 약제 */}
      <div className="bg-[#161B27] rounded-2xl border border-[#1E2530] p-5">
        <div className="flex items-center gap-2 mb-3">
          <span className="w-8 h-8 rounded-lg bg-[#00E5CC]/10 flex items-center justify-center">
            <i className="ri-medicine-bottle-line text-[#00E5CC] text-base"></i>
          </span>
          <div>
            <p className="text-[#8B9BB4] text-xs">한국MSD 현재 급여 약제</p>
          </div>
        </div>
        <div className="flex items-end gap-2">
          <span className="text-4xl font-bold text-[#00E5CC]">{msdReimbursedDrugs.total}</span>
          <span className="text-[#8B9BB4] text-sm mb-1">개 품목</span>
        </div>
        <p className="text-[#4A5568] text-xs mt-2">건강보험 급여 등재 기준 (2025.04 현재)</p>
      </div>

      {/* Keytruda 급여/비급여 */}
      <div className="bg-[#161B27] rounded-2xl border border-[#1E2530] p-5">
        <div className="flex items-center gap-2 mb-3">
          <span className="w-8 h-8 rounded-lg bg-[#F59E0B]/10 flex items-center justify-center">
            <i className="ri-capsule-line text-[#F59E0B] text-base"></i>
          </span>
          <p className="text-[#8B9BB4] text-xs">Keytruda 적응증 현황</p>
        </div>
        <div className="flex items-center gap-4 mb-3">
          <div>
            <p className="text-3xl font-bold text-[#00E5CC]">{msdReimbursedDrugs.keytruda.reimbursed}</p>
            <p className="text-[#8B9BB4] text-xs mt-0.5">급여 적응증</p>
          </div>
          <div className="w-px h-10 bg-[#1E2530]"></div>
          <div>
            <p className="text-3xl font-bold text-[#F59E0B]">{msdReimbursedDrugs.keytruda.nonReimbursedApproved}</p>
            <p className="text-[#8B9BB4] text-xs mt-0.5">비급여 허가</p>
          </div>
        </div>
        <button
          onClick={() => setShowKeytrudaDetail(!showKeytrudaDetail)}
          className="text-[#00E5CC] text-xs flex items-center gap-1 cursor-pointer hover:text-[#00C9B1] transition-colors whitespace-nowrap"
        >
          {showKeytrudaDetail ? '접기' : '적응증 목록 보기'}
          <span className="w-3 h-3 flex items-center justify-center">
            <i className={showKeytrudaDetail ? 'ri-arrow-up-s-line text-xs' : 'ri-arrow-down-s-line text-xs'}></i>
          </span>
        </button>
        {showKeytrudaDetail && (
          <div className="mt-3 max-h-48 overflow-y-auto space-y-1.5 pr-1">
            {msdReimbursedDrugs.keytruda.indications.map((ind, i) => (
              <div key={i} className="flex items-start gap-2">
                <span className={`text-xs px-1.5 py-0.5 rounded flex-shrink-0 mt-0.5 ${ind.type === '급여' ? 'bg-[#00E5CC]/10 text-[#00E5CC]' : 'bg-[#F59E0B]/10 text-[#F59E0B]'}`}>
                  {ind.type}
                </span>
                <span className="text-[#8B9BB4] text-xs leading-relaxed">{ind.name}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* New Pipeline — 올해/+1/+2년 카드 */}
      <div className="bg-[#161B27] rounded-2xl border border-[#1E2530] p-5">
        <div className="flex items-center gap-2 mb-3">
          <span className="w-8 h-8 rounded-lg bg-[#7C3AED]/10 flex items-center justify-center">
            <i className="ri-flask-line text-[#7C3AED] text-base"></i>
          </span>
          <p className="text-[#8B9BB4] text-xs">New Pipeline 현황</p>
        </div>

        {/* 현재 진행 + 연도별 숫자 카드 */}
        <div className="grid grid-cols-4 gap-2 mb-3">
          {/* 현재 진행 */}
          <button
            onClick={() => {
              setPipelineYear(null);
              setShowPipelineDetail(prev => pipelineYear !== null ? true : !prev);
            }}
            className={`rounded-xl p-2.5 border text-center cursor-pointer transition-all ${
              showPipelineDetail && pipelineYear === null
                ? 'border-[#00E5CC]/50 bg-[#00E5CC]/10'
                : 'border-[#1E2530] hover:border-[#2A3545]'
            }`}
          >
            <p className="text-xl font-bold text-[#00E5CC]">{currentPipeline.length}</p>
            <p className="text-[#4A5568] text-[10px] mt-0.5 leading-tight">현재<br />진행</p>
          </button>

          {/* 올해 / +1 / +2 */}
          {yearGroups.map(g => (
            <button
              key={g.year}
              onClick={() => {
                if (pipelineYear === g.year && showPipelineDetail) {
                  setShowPipelineDetail(false);
                  setPipelineYear(null);
                } else {
                  setPipelineYear(g.year);
                  setShowPipelineDetail(true);
                }
              }}
              className={`rounded-xl p-2.5 border text-center cursor-pointer transition-all ${
                showPipelineDetail && pipelineYear === g.year
                  ? 'border-opacity-50 bg-opacity-10'
                  : 'border-[#1E2530] hover:border-[#2A3545]'
              }`}
              style={
                showPipelineDetail && pipelineYear === g.year
                  ? { borderColor: `${g.color}80`, backgroundColor: `${g.color}15` }
                  : {}
              }
            >
              <p className="text-xl font-bold" style={{ color: g.color }}>{g.items.length}</p>
              <p className="text-[#4A5568] text-[10px] mt-0.5 leading-tight">
                {g.sublabel}<br />{g.label.replace('년', '')}
              </p>
            </button>
          ))}
        </div>

        {/* 목록 보기 토글 */}
        <button
          onClick={() => {
            if (!showPipelineDetail) {
              setShowPipelineDetail(true);
              setPipelineYear(null);
            } else {
              setShowPipelineDetail(false);
              setPipelineYear(null);
            }
          }}
          className="text-[#00E5CC] text-xs flex items-center gap-1 cursor-pointer hover:text-[#00C9B1] transition-colors whitespace-nowrap"
        >
          {showPipelineDetail ? '접기' : '파이프라인 목록 보기'}
          <span className="w-3 h-3 flex items-center justify-center">
            <i className={showPipelineDetail ? 'ri-arrow-up-s-line text-xs' : 'ri-arrow-down-s-line text-xs'}></i>
          </span>
        </button>

        {/* 목록 패널 */}
        {showPipelineDetail && (
          <div className="mt-3 max-h-52 overflow-y-auto space-y-1.5 pr-1">
            {/* 현재 진행 목록 */}
            {pipelineYear === null && (
              <>
                <p className="text-[#4A5568] text-[10px] font-semibold uppercase tracking-wider mb-1">현재 진행 중</p>
                {currentPipeline.map((p, i) => (
                  <div key={i} className="flex items-start gap-2 py-1">
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#00E5CC]/10 text-[#00E5CC] flex-shrink-0 mt-0.5 whitespace-nowrap">{p.phase}</span>
                    <div>
                      <p className="text-white text-xs font-medium leading-tight">{p.name}</p>
                      <p className="text-[#4A5568] text-[10px]">{p.indication}</p>
                    </div>
                  </div>
                ))}
              </>
            )}

            {/* 연도별 목록 */}
            {pipelineYear !== null && selectedYearGroup && (
              <>
                <p className="text-[10px] font-semibold uppercase tracking-wider mb-1" style={{ color: selectedYearGroup.color }}>
                  {selectedYearGroup.label} 예정 ({selectedYearGroup.items.length}개)
                </p>
                {selectedYearGroup.items.length === 0 && (
                  <p className="text-[#4A5568] text-xs py-2">해당 연도 예정 파이프라인 없음</p>
                )}
                {selectedYearGroup.items.map((p, i) => (
                  <div key={i} className="flex items-start gap-2 py-1">
                    <span
                      className="text-[10px] px-1.5 py-0.5 rounded flex-shrink-0 mt-0.5 whitespace-nowrap"
                      style={{ backgroundColor: `${selectedYearGroup.color}20`, color: selectedYearGroup.color }}
                    >
                      {p.phase}
                    </span>
                    <div>
                      <p className="text-white text-xs font-medium leading-tight">{p.name}</p>
                      <p className="text-[#4A5568] text-[10px]">{p.indication}</p>
                    </div>
                  </div>
                ))}
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
