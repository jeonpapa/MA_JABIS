import { useState } from 'react';
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
} from 'recharts';
import { salesTrendData } from '@/mocks/dashboardData';

const PRODUCTS = [
  { key: 'ProductA', name: 'Nexavir', color: '#00E5CC' },
  { key: 'ProductB', name: 'Cardiomax', color: '#7C3AED' },
  { key: 'ProductC', name: 'Oncovance', color: '#F59E0B' },
  { key: 'ProductD', name: 'Diabecare', color: '#EF4444' },
];

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-[#1E2530] border border-[#2A3545] rounded-xl p-3 shadow-xl">
        <p className="text-white text-xs font-bold mb-2">{label}</p>
        {payload.map((entry: any) => (
          <div key={entry.dataKey} className="flex items-center gap-2 text-xs mb-1">
            <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ backgroundColor: entry.color }}></span>
            <span className="text-[#8B9BB4]">{entry.name}:</span>
            <span className="text-white font-semibold">{entry.value.toLocaleString()}백만원</span>
          </div>
        ))}
      </div>
    );
  }
  return null;
};

export default function SalesTrendChart() {
  const [activeProducts, setActiveProducts] = useState<string[]>(PRODUCTS.map(p => p.key));

  const toggleProduct = (key: string) => {
    setActiveProducts(prev =>
      prev.includes(key) ? prev.filter(k => k !== key) : [...prev, key]
    );
  };

  return (
    <div className="bg-[#161B27] rounded-2xl p-6 border border-[#1E2530]">
      <div className="flex items-center justify-between mb-5">
        <div>
          <h3 className="text-white font-bold text-base">제품별 매출 추이</h3>
          <p className="text-[#8B9BB4] text-xs mt-0.5">2025년 월별 매출 (단위: 백만원)</p>
        </div>
        <div className="flex gap-2">
          {PRODUCTS.map(p => (
            <button
              key={p.key}
              onClick={() => toggleProduct(p.key)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium transition-all cursor-pointer whitespace-nowrap border ${
                activeProducts.includes(p.key)
                  ? 'border-transparent text-[#0A0E1A]'
                  : 'border-[#2A3545] text-[#8B9BB4] bg-transparent'
              }`}
              style={activeProducts.includes(p.key) ? { backgroundColor: p.color } : {}}
            >
              {p.name}
            </button>
          ))}
        </div>
      </div>
      <ResponsiveContainer width="100%" height={260}>
        <LineChart data={salesTrendData} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#1E2530" />
          <XAxis dataKey="month" tick={{ fill: '#8B9BB4', fontSize: 11 }} axisLine={false} tickLine={false} />
          <YAxis tick={{ fill: '#8B9BB4', fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={(v) => `${v.toLocaleString()}`} />
          <Tooltip content={<CustomTooltip />} />
          {PRODUCTS.map(p => (
            activeProducts.includes(p.key) && (
              <Line
                key={p.key}
                type="monotone"
                dataKey={p.key}
                name={p.name}
                stroke={p.color}
                strokeWidth={2.5}
                dot={false}
                activeDot={{ r: 5, strokeWidth: 0 }}
              />
            )
          ))}
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
