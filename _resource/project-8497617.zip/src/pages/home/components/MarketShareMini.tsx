import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from 'recharts';
import { marketShareData } from '@/mocks/dashboardData';

const CustomTooltip = ({ active, payload }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-[#1E2530] border border-[#2A3545] rounded-xl p-3 shadow-xl">
        <p className="text-white text-xs font-bold">{payload[0].name}</p>
        <p className="text-[#00E5CC] text-sm font-bold">{payload[0].value}%</p>
      </div>
    );
  }
  return null;
};

export default function MarketShareMini() {
  const total = marketShareData.reduce((sum, d) => sum + d.value, 0);

  return (
    <div className="bg-[#161B27] rounded-2xl p-6 border border-[#1E2530] h-full">
      <div className="mb-4">
        <h3 className="text-white font-bold text-base">시장 점유율</h3>
        <p className="text-[#8B9BB4] text-xs mt-0.5">2025년 1분기 기준</p>
      </div>
      <div className="flex flex-col items-center">
        <div className="relative w-full" style={{ height: 200 }}>
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={marketShareData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={90}
                paddingAngle={3}
                dataKey="value"
              >
                {marketShareData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} stroke="transparent" />
                ))}
              </Pie>
              <Tooltip content={<CustomTooltip />} />
            </PieChart>
          </ResponsiveContainer>
          <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
            <p className="text-[#8B9BB4] text-xs">총 시장</p>
            <p className="text-white text-xl font-bold">₩2.4조</p>
          </div>
        </div>
        <div className="w-full space-y-2 mt-2">
          {marketShareData.map((item) => (
            <div key={item.name} className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ backgroundColor: item.color }}></span>
              <span className="text-[#8B9BB4] text-xs flex-1">{item.name}</span>
              <div className="flex items-center gap-2">
                <div className="w-16 h-1.5 bg-[#1E2530] rounded-full overflow-hidden">
                  <div className="h-full rounded-full" style={{ width: `${(item.value / total) * 100}%`, backgroundColor: item.color }}></div>
                </div>
                <span className="text-white text-xs font-semibold w-10 text-right">{item.value}%</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
