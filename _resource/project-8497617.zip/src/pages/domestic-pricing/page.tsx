import { useState, useMemo } from 'react';
import { domesticPricingData } from '@/mocks/dashboardData';
import PriceWaterfall from './components/PriceWaterfall';
import AnalogueCompareModal from './components/AnalogueCompareModal';

type DrugItem = typeof domesticPricingData[0];

export default function DomesticPricingPage() {
  const [search, setSearch] = useState('');
  const [selectedDrug, setSelectedDrug] = useState<DrugItem | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [selectedAnalogues, setSelectedAnalogues] = useState<string[]>([]);

  const filtered = useMemo(() => {
    if (!search) return domesticPricingData;
    const q = search.toLowerCase();
    return domesticPricingData.filter(d =>
      d.productName.toLowerCase().includes(q) ||
      d.ingredient.toLowerCase().includes(q) ||
      d.insuranceCode.toLowerCase().includes(q)
    );
  }, [search]);

  const handleSelect = (drug: DrugItem) => {
    setSelectedDrug(drug);
    setSelectedAnalogues([]);
  };

  const handleToggleAnalogue = (name: string) => {
    setSelectedAnalogues(prev =>
      prev.includes(name) ? prev.filter(n => n !== name) : [...prev, name]
    );
  };

  const compareList = selectedDrug
    ? [
        { name: selectedDrug.productName, price: selectedDrug.currentPrice, dailyCost: selectedDrug.dailyCost, isBase: true },
        ...(selectedDrug.analogues || [])
          .filter(a => selectedAnalogues.includes(a.name))
          .map(a => ({ name: a.name, price: a.price, dailyCost: a.dailyCost, isBase: false })),
      ]
    : [];

  return (
    <div className="min-h-screen bg-[#0D1117] text-white">
      {/* Header */}
      <div className="px-8 pt-8 pb-6 border-b border-[#1E2530]">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="w-5 h-5 flex items-center justify-center"><i className="ri-price-tag-3-line text-[#00E5CC]"></i></span>
              <h1 className="text-2xl font-bold text-white">국내약가</h1>
            </div>
            <p className="text-[#8B9BB4] text-sm">건강보험 등재 약가 상세 정보 및 변동 이력</p>
          </div>
          <button className="flex items-center gap-2 bg-[#00E5CC] text-[#0A0E1A] text-sm font-semibold px-4 py-2 rounded-lg cursor-pointer whitespace-nowrap hover:bg-[#00C9B1] transition-colors">
            <span className="w-4 h-4 flex items-center justify-center"><i className="ri-download-2-line text-sm"></i></span>
            엑셀 다운로드
          </button>
        </div>
      </div>

      <div className="px-8 py-6 space-y-5">
        {/* Search */}
        <div className="bg-[#161B27] rounded-2xl border border-[#1E2530] px-5 py-4 flex items-center gap-3">
          <span className="w-5 h-5 flex items-center justify-center text-[#8B9BB4]">
            <i className="ri-search-line text-base"></i>
          </span>
          <input
            type="text"
            placeholder="제품명, 성분명, 보험코드로 검색..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="bg-transparent text-white text-sm placeholder-[#4A5568] focus:outline-none flex-1"
          />
          {search && (
            <button onClick={() => setSearch('')} className="w-5 h-5 flex items-center justify-center text-[#4A5568] hover:text-white cursor-pointer transition-colors">
              <i className="ri-close-line text-sm"></i>
            </button>
          )}
        </div>

        {/* Product List */}
        <div className="bg-[#161B27] rounded-2xl border border-[#1E2530] overflow-hidden">
          <div className="px-5 py-3 border-b border-[#1E2530] flex items-center justify-between">
            <p className="text-[#8B9BB4] text-xs">총 <span className="text-white font-semibold">{filtered.length}</span>개 품목</p>
            <p className="text-[#4A5568] text-xs">클릭하여 상세 정보 확인</p>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-[#1E2530]">
                  <th className="text-left text-[#8B9BB4] text-xs font-semibold px-5 py-3 whitespace-nowrap">제품명</th>
                  <th className="text-left text-[#8B9BB4] text-xs font-semibold px-4 py-3 whitespace-nowrap">성분명</th>
                  <th className="text-left text-[#8B9BB4] text-xs font-semibold px-4 py-3 whitespace-nowrap">보험코드</th>
                  <th className="text-left text-[#8B9BB4] text-xs font-semibold px-4 py-3 whitespace-nowrap">분류</th>
                  <th className="text-right text-[#8B9BB4] text-xs font-semibold px-4 py-3 whitespace-nowrap">현재 상한금액</th>
                  <th className="text-center text-[#8B9BB4] text-xs font-semibold px-4 py-3 whitespace-nowrap">변동률</th>
                  <th className="text-center text-[#8B9BB4] text-xs font-semibold px-4 py-3 whitespace-nowrap">RSA</th>
                  <th className="text-left text-[#8B9BB4] text-xs font-semibold px-4 py-3 whitespace-nowrap">최종 변경일</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((item, idx) => (
                  <tr
                    key={item.id}
                    onClick={() => handleSelect(item)}
                    className={`border-t border-[#1E2530] hover:bg-[#00E5CC]/5 transition-colors cursor-pointer ${
                      selectedDrug?.id === item.id ? 'bg-[#00E5CC]/10' : idx % 2 === 1 ? 'bg-[#1A2035]/20' : ''
                    }`}
                  >
                    <td className="px-5 py-3 text-white text-sm font-medium whitespace-nowrap">{item.productName}</td>
                    <td className="px-4 py-3 text-[#8B9BB4] text-sm whitespace-nowrap">{item.ingredient}</td>
                    <td className="px-4 py-3 text-[#8B9BB4] text-xs font-mono whitespace-nowrap">{item.insuranceCode}</td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <span className="text-xs px-2 py-1 rounded-full bg-[#1E2530] text-[#8B9BB4]">{item.category}</span>
                    </td>
                    <td className="px-4 py-3 text-white text-sm font-semibold text-right whitespace-nowrap">
                      ₩{item.currentPrice.toLocaleString()}
                    </td>
                    <td className="px-4 py-3 text-center whitespace-nowrap">
                      {item.change !== null ? (
                        <span className={`text-xs font-semibold px-2 py-1 rounded-full ${
                          item.change < 0 ? 'text-red-400 bg-red-400/10' :
                          item.change > 0 ? 'text-emerald-400 bg-emerald-400/10' :
                          'text-[#8B9BB4] bg-[#8B9BB4]/10'
                        }`}>
                          {item.change > 0 ? '+' : ''}{item.change}%
                        </span>
                      ) : <span className="text-[#4A5568] text-xs">-</span>}
                    </td>
                    <td className="px-4 py-3 text-center whitespace-nowrap">
                      {item.hasRSA ? (
                        <span className="text-xs px-2 py-1 rounded-full bg-amber-400/10 text-amber-400 font-semibold">RSA</span>
                      ) : (
                        <span className="text-[#4A5568] text-xs">-</span>
                      )}
                    </td>
                    <td className="px-4 py-3 text-[#8B9BB4] text-xs whitespace-nowrap">{item.lastUpdated}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            {filtered.length === 0 && (
              <div className="text-center py-12 text-[#4A5568]">
                <span className="w-8 h-8 flex items-center justify-center mx-auto mb-2"><i className="ri-search-line text-2xl"></i></span>
                <p className="text-sm">검색 결과가 없습니다</p>
              </div>
            )}
          </div>
        </div>

        {/* Detail Panel */}
        {selectedDrug && (
          <div className="space-y-4">
            {/* Basic Info + Detail Info */}
            <div className="grid grid-cols-2 gap-4">
              {/* 기본정보 */}
              <div className="bg-[#161B27] rounded-2xl border border-[#1E2530] p-5">
                <div className="flex items-center gap-2 mb-4">
                  <span className="w-5 h-5 flex items-center justify-center">
                    <i className="ri-information-line text-[#00E5CC]"></i>
                  </span>
                  <h3 className="text-white font-bold text-sm">기본 정보</h3>
                  <span className="ml-auto text-[#00E5CC] text-xs font-semibold">{selectedDrug.productName}</span>
                </div>
                <div className="space-y-3">
                  <div className="flex items-center justify-between py-2 border-b border-[#1E2530]">
                    <span className="text-[#8B9BB4] text-xs">최초 약가 등재일</span>
                    <span className="text-white text-sm font-medium">{selectedDrug.firstRegistDate}</span>
                  </div>
                  <div className="flex items-center justify-between py-2 border-b border-[#1E2530]">
                    <span className="text-[#8B9BB4] text-xs">현재 상한금액</span>
                    <span className="text-[#00E5CC] text-sm font-bold">₩{selectedDrug.currentPrice.toLocaleString()}</span>
                  </div>
                  <div className="flex items-center justify-between py-2 border-b border-[#1E2530]">
                    <span className="text-[#8B9BB4] text-xs">약가 변동 이력 횟수</span>
                    <span className="text-white text-sm font-medium">{selectedDrug.priceChangeCount}회</span>
                  </div>
                  <div className="flex items-center justify-between py-2">
                    <span className="text-[#8B9BB4] text-xs">최초 약가 대비 변동률</span>
                    <span className={`text-sm font-bold ${selectedDrug.changeRateFromFirst < 0 ? 'text-red-400' : 'text-emerald-400'}`}>
                      {selectedDrug.changeRateFromFirst > 0 ? '+' : ''}{selectedDrug.changeRateFromFirst}%
                    </span>
                  </div>
                </div>
              </div>

              {/* 상세정보 */}
              <div className="bg-[#161B27] rounded-2xl border border-[#1E2530] p-5">
                <div className="flex items-center gap-2 mb-4">
                  <span className="w-5 h-5 flex items-center justify-center">
                    <i className="ri-file-list-3-line text-[#7C3AED]"></i>
                  </span>
                  <h3 className="text-white font-bold text-sm">상세 정보</h3>
                </div>
                <div className="space-y-3">
                  <div className="flex items-center justify-between py-2 border-b border-[#1E2530]">
                    <span className="text-[#8B9BB4] text-xs">RSA 여부</span>
                    <div className="flex items-center gap-2">
                      {selectedDrug.hasRSA ? (
                        <>
                          <span className="text-xs px-2 py-0.5 rounded-full bg-amber-400/10 text-amber-400 font-semibold">적용</span>
                          <span className="text-[#8B9BB4] text-xs">{selectedDrug.rsaType}</span>
                        </>
                      ) : (
                        <span className="text-[#4A5568] text-xs">해당없음</span>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center justify-between py-2 border-b border-[#1E2530]">
                    <span className="text-[#8B9BB4] text-xs">약제평가위원회 문서</span>
                    <span className="text-white text-xs">{selectedDrug.evalCommitteeDoc}</span>
                  </div>
                  <div className="flex items-center justify-between py-2 border-b border-[#1E2530]">
                    <span className="text-[#8B9BB4] text-xs">최초 허가일</span>
                    <span className="text-white text-xs">{selectedDrug.firstApprovalDate}</span>
                  </div>
                  <div className="flex items-start justify-between py-2 border-b border-[#1E2530]">
                    <span className="text-[#8B9BB4] text-xs flex-shrink-0">용법용량</span>
                    <span className="text-white text-xs text-right ml-4">{selectedDrug.dosage}</span>
                  </div>
                  <div className="grid grid-cols-3 gap-2 pt-1">
                    <div className="bg-[#1E2530] rounded-lg p-2 text-center">
                      <p className="text-[#4A5568] text-xs mb-1">일치료비</p>
                      <p className="text-white text-xs font-bold">
                        {selectedDrug.dailyCost ? `₩${selectedDrug.dailyCost.toLocaleString()}` : '-'}
                      </p>
                    </div>
                    <div className="bg-[#1E2530] rounded-lg p-2 text-center">
                      <p className="text-[#4A5568] text-xs mb-1">월치료비</p>
                      <p className="text-white text-xs font-bold">
                        {selectedDrug.monthlyCost ? `₩${selectedDrug.monthlyCost.toLocaleString()}` : '-'}
                      </p>
                    </div>
                    <div className="bg-[#1E2530] rounded-lg p-2 text-center">
                      <p className="text-[#4A5568] text-xs mb-1">연치료비</p>
                      <p className="text-white text-xs font-bold">
                        {selectedDrug.yearlyCost ? `₩${selectedDrug.yearlyCost.toLocaleString()}` : '-'}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* 약제 비교 */}
            <div className="bg-[#161B27] rounded-2xl border border-[#1E2530] p-5">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <span className="w-5 h-5 flex items-center justify-center">
                    <i className="ri-scales-3-line text-[#F59E0B]"></i>
                  </span>
                  <h3 className="text-white font-bold text-sm">약제 비교</h3>
                  <span className="text-[#4A5568] text-xs">(최대 3개)</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-[#8B9BB4] text-xs">
                    동일성분 등재 품목: <span className="text-white font-semibold">{selectedDrug.sameIngredientCount}개</span>
                  </span>
                  <button
                    onClick={() => setShowModal(true)}
                    className="flex items-center gap-1.5 bg-[#1E2530] border border-[#2A3545] text-[#8B9BB4] hover:text-white text-xs px-3 py-1.5 rounded-lg cursor-pointer transition-colors whitespace-nowrap"
                  >
                    <span className="w-4 h-4 flex items-center justify-center"><i className="ri-add-line text-sm"></i></span>
                    아날로그 선택
                  </button>
                </div>
              </div>

              {compareList.length > 0 ? (
                <div className="grid gap-3" style={{ gridTemplateColumns: `repeat(${compareList.length}, 1fr)` }}>
                  {compareList.map((item) => (
                    <div
                      key={item.name}
                      className={`rounded-xl p-4 border ${item.isBase ? 'border-[#00E5CC]/40 bg-[#00E5CC]/5' : 'border-[#1E2530] bg-[#1E2530]'}`}
                    >
                      {item.isBase && (
                        <span className="text-xs px-2 py-0.5 rounded-full bg-[#00E5CC]/20 text-[#00E5CC] font-semibold mb-2 inline-block">기준</span>
                      )}
                      <p className="text-white text-sm font-bold mb-3 leading-snug">{item.name}</p>
                      <div className="space-y-2">
                        <div>
                          <p className="text-[#4A5568] text-xs mb-0.5">약가</p>
                          <p className="text-white text-base font-bold">₩{item.price.toLocaleString()}</p>
                        </div>
                        {item.dailyCost && (
                          <div>
                            <p className="text-[#4A5568] text-xs mb-0.5">일치료비</p>
                            <p className={`text-sm font-semibold ${item.isBase ? 'text-[#00E5CC]' : 'text-white'}`}>
                              ₩{item.dailyCost.toLocaleString()}
                            </p>
                            {!item.isBase && compareList[0].dailyCost && (
                              <p className={`text-xs mt-0.5 ${item.dailyCost > compareList[0].dailyCost ? 'text-red-400' : 'text-emerald-400'}`}>
                                기준 대비 {item.dailyCost > compareList[0].dailyCost ? '+' : ''}
                                {(((item.dailyCost - compareList[0].dailyCost) / compareList[0].dailyCost) * 100).toFixed(1)}%
                              </p>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-[#4A5568]">
                  <span className="w-8 h-8 flex items-center justify-center mx-auto mb-2"><i className="ri-add-circle-line text-2xl"></i></span>
                  <p className="text-sm">아날로그 약제를 선택하여 비교하세요</p>
                </div>
              )}
            </div>

            {/* Waterfall Chart */}
            <PriceWaterfall history={selectedDrug.priceHistory} productName={selectedDrug.productName} />

            {/* Price History Table */}
            <div className="bg-[#161B27] rounded-2xl border border-[#1E2530] overflow-hidden">
              <div className="px-5 py-4 border-b border-[#1E2530] flex items-center gap-2">
                <span className="w-5 h-5 flex items-center justify-center">
                  <i className="ri-history-line text-[#00E5CC]"></i>
                </span>
                <h3 className="text-white font-bold text-sm">가격 변동 이력 테이블</h3>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="bg-[#1E2530]">
                      <th className="text-left text-[#8B9BB4] text-xs font-semibold px-5 py-3 whitespace-nowrap">등재시점</th>
                      <th className="text-left text-[#8B9BB4] text-xs font-semibold px-4 py-3 whitespace-nowrap">구분</th>
                      <th className="text-left text-[#8B9BB4] text-xs font-semibold px-4 py-3 whitespace-nowrap">주성분</th>
                      <th className="text-left text-[#8B9BB4] text-xs font-semibold px-4 py-3 whitespace-nowrap">업체명</th>
                      <th className="text-right text-[#8B9BB4] text-xs font-semibold px-4 py-3 whitespace-nowrap">상한금액 (원)</th>
                      <th className="text-center text-[#8B9BB4] text-xs font-semibold px-4 py-3 whitespace-nowrap">변동률</th>
                      <th className="text-left text-[#8B9BB4] text-xs font-semibold px-4 py-3 whitespace-nowrap">변동사유</th>
                    </tr>
                  </thead>
                  <tbody>
                    {selectedDrug.priceHistory.map((h, idx) => (
                      <tr key={idx} className={`border-t border-[#1E2530] hover:bg-[#00E5CC]/5 transition-colors ${idx % 2 === 1 ? 'bg-[#1A2035]/20' : ''}`}>
                        <td className="px-5 py-3 text-white text-sm whitespace-nowrap">{h.date}</td>
                        <td className="px-4 py-3 whitespace-nowrap">
                          <span className={`text-xs px-2 py-1 rounded-full font-semibold ${
                            h.type === '최초등재' ? 'bg-[#00E5CC]/10 text-[#00E5CC]' :
                            h.type === '약가인하' ? 'bg-red-400/10 text-red-400' :
                            h.type === '약가인상' ? 'bg-emerald-400/10 text-emerald-400' :
                            'bg-[#4A5568]/20 text-[#8B9BB4]'
                          }`}>
                            {h.type}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-[#8B9BB4] text-sm whitespace-nowrap">{selectedDrug.ingredient}</td>
                        <td className="px-4 py-3 text-[#8B9BB4] text-sm whitespace-nowrap">한국MSD</td>
                        <td className="px-4 py-3 text-white text-sm font-semibold text-right whitespace-nowrap">
                          ₩{h.price.toLocaleString()}
                        </td>
                        <td className="px-4 py-3 text-center whitespace-nowrap">
                          {h.changeRate !== null ? (
                            <span className={`text-xs font-semibold ${h.changeRate < 0 ? 'text-red-400' : h.changeRate > 0 ? 'text-emerald-400' : 'text-[#8B9BB4]'}`}>
                              {h.changeRate > 0 ? '+' : ''}{h.changeRate}%
                            </span>
                          ) : <span className="text-[#4A5568] text-xs">-</span>}
                        </td>
                        <td className="px-4 py-3 text-[#8B9BB4] text-xs whitespace-nowrap">{h.reason}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {!selectedDrug && (
          <div className="bg-[#161B27] rounded-2xl border border-[#1E2530] py-16 text-center">
            <span className="w-12 h-12 flex items-center justify-center mx-auto mb-3 text-[#4A5568]">
              <i className="ri-price-tag-3-line text-4xl"></i>
            </span>
            <p className="text-[#8B9BB4] text-sm">위 목록에서 약제를 클릭하면 상세 정보가 표시됩니다</p>
          </div>
        )}
      </div>

      {/* Analogue Modal */}
      {selectedDrug && (
        <AnalogueCompareModal
          open={showModal}
          onClose={() => setShowModal(false)}
          baseProduct={{ name: selectedDrug.productName, price: selectedDrug.currentPrice, dailyCost: selectedDrug.dailyCost }}
          analogues={selectedDrug.analogues || []}
          selected={selectedAnalogues}
          onToggle={handleToggleAnalogue}
        />
      )}
    </div>
  );
}
