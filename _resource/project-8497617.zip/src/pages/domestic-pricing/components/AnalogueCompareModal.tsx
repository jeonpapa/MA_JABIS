interface Analogue {
  name: string;
  ingredient: string;
  price: number;
  dailyCost: number | null;
  company: string;
}

interface Props {
  open: boolean;
  onClose: () => void;
  baseProduct: { name: string; price: number; dailyCost: number | null };
  analogues: Analogue[];
  selected: string[];
  onToggle: (name: string) => void;
}

export default function AnalogueCompareModal({ open, onClose, baseProduct, analogues, selected, onToggle }: Props) {
  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/60" onClick={onClose}></div>
      <div className="relative bg-[#161B27] border border-[#2A3545] rounded-2xl w-full max-w-lg mx-4 p-6 shadow-2xl">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-white font-bold text-base">아날로그 약제 선택</h3>
          <button onClick={onClose} className="w-7 h-7 flex items-center justify-center text-[#8B9BB4] hover:text-white cursor-pointer transition-colors">
            <i className="ri-close-line text-lg"></i>
          </button>
        </div>
        <p className="text-[#8B9BB4] text-xs mb-4">최대 2개까지 선택하여 비교할 수 있습니다 (기준 약제 포함 최대 3개)</p>

        {/* Base product */}
        <div className="bg-[#00E5CC]/10 border border-[#00E5CC]/30 rounded-xl p-3 mb-3">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-[#00E5CC] text-xs font-semibold mb-0.5">기준 약제</p>
              <p className="text-white text-sm font-bold">{baseProduct.name}</p>
            </div>
            <div className="text-right">
              <p className="text-white text-sm font-bold">₩{baseProduct.price.toLocaleString()}</p>
              {baseProduct.dailyCost && (
                <p className="text-[#8B9BB4] text-xs">일치료비 ₩{baseProduct.dailyCost.toLocaleString()}</p>
              )}
            </div>
          </div>
        </div>

        {/* Analogues */}
        <div className="space-y-2">
          {analogues.map((a) => {
            const isSelected = selected.includes(a.name);
            const isDisabled = !isSelected && selected.length >= 2;
            return (
              <button
                key={a.name}
                onClick={() => !isDisabled && onToggle(a.name)}
                className={`w-full text-left rounded-xl p-3 border transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-[#7C3AED]/10 border-[#7C3AED]/40'
                    : isDisabled
                    ? 'bg-[#1E2530] border-[#1E2530] opacity-40 cursor-not-allowed'
                    : 'bg-[#1E2530] border-[#1E2530] hover:border-[#2A3545]'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className={`w-4 h-4 rounded flex items-center justify-center flex-shrink-0 ${isSelected ? 'bg-[#7C3AED]' : 'border border-[#4A5568]'}`}>
                      {isSelected && <i className="ri-check-line text-white text-xs"></i>}
                    </div>
                    <div>
                      <p className="text-white text-sm font-medium">{a.name}</p>
                      <p className="text-[#8B9BB4] text-xs">{a.ingredient} · {a.company}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-white text-sm font-semibold">₩{a.price.toLocaleString()}</p>
                    {a.dailyCost && (
                      <p className="text-[#8B9BB4] text-xs">일치료비 ₩{a.dailyCost.toLocaleString()}</p>
                    )}
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        <button
          onClick={onClose}
          className="mt-4 w-full bg-[#00E5CC] text-[#0A0E1A] font-semibold text-sm py-2.5 rounded-xl cursor-pointer hover:bg-[#00C9B1] transition-colors whitespace-nowrap"
        >
          선택 완료
        </button>
      </div>
    </div>
  );
}
