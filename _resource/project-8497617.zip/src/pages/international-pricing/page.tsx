import { useState } from 'react';
import { internationalPricingData } from '@/mocks/dashboardData';

type DrugItem = typeof internationalPricingData[0];

const A8_COUNTRIES = [
  { key: 'usa', label: '미국', flag: '🇺🇸', currency: 'USD' },
  { key: 'uk', label: '영국', flag: '🇬🇧', currency: 'GBP' },
  { key: 'germany', label: '독일', flag: '🇩🇪', currency: 'EUR' },
  { key: 'france', label: '프랑스', flag: '🇫🇷', currency: 'EUR' },
  { key: 'canada', label: '캐나다', flag: '🇨🇦', currency: 'CAD' },
  { key: 'japan', label: '일본', flag: '🇯🇵', currency: 'JPY' },
  { key: 'italy', label: '이탈리아', flag: '🇮🇹', currency: 'EUR' },
  { key: 'switzerland', label: '스위스', flag: '🇨🇭', currency: 'CHF' },
];

const HTA_COUNTRIES = [
  { key: 'uk', label: '영국', flag: '🇬🇧', body: 'NICE' },
  { key: 'canada', label: '캐나다', flag: '🇨🇦', body: 'CADTH' },
  { key: 'australia', label: '호주', flag: '🇦🇺', body: 'PBAC' },
  { key: 'scotland', label: '스코틀랜드', flag: '🏴󠁧󠁢󠁳󠁣󠁴󠁿', body: 'SMC' },
];

const ALL_APPROVAL_COUNTRIES = [
  { key: 'usa', label: '미국', flag: '🇺🇸' },
  { key: 'uk', label: '영국', flag: '🇬🇧' },
  { key: 'germany', label: '독일', flag: '🇩🇪' },
  { key: 'france', label: '프랑스', flag: '🇫🇷' },
  { key: 'canada', label: '캐나다', flag: '🇨🇦' },
  { key: 'japan', label: '일본', flag: '🇯🇵' },
  { key: 'italy', label: '이탈리아', flag: '🇮🇹' },
  { key: 'switzerland', label: '스위스', flag: '🇨🇭' },
  { key: 'australia', label: '호주', flag: '🇦🇺' },
  { key: 'scotland', label: '스코틀랜드', flag: '🏴󠁧󠁢󠁳󠁣󠁴󠁿' },
];

const getCurrencySymbol = (currency: string) => {
  const map: Record<string, string> = { USD: '$', GBP: '£', JPY: '¥', CHF: 'Fr.', EUR: '€', CAD: 'CA$' };
  return map[currency] || currency;
};

const getStatusBadgeClass = (status: string) => {
  if (status === '권고') return 'bg-emerald-400/10 text-emerald-400 border border-emerald-400/20';
  if (status === '조건부 권고') return 'bg-amber-400/10 text-amber-400 border border-amber-400/20';
  if (status === '비권고') return 'bg-red-400/10 text-red-400 border border-red-400/20';
  return 'bg-[#4A5568]/20 text-[#8B9BB4]';
};

export default function InternationalPricingPage() {
  const [newSearchQuery, setNewSearchQuery] = useState('');
  const [selectedDrug, setSelectedDrug] = useState<DrugItem | null>(null);
  const [activeTab, setActiveTab] = useState<'pricing' | 'hta' | 'approval'>('pricing');
  const [expandedHta, setExpandedHta] = useState<string | null>(null);
  const [expandedApproval, setExpandedApproval] = useState<string | null>(null);
  const [searchDropdown, setSearchDropdown] = useState(false);

  const historyItems = internationalPricingData.filter(d => d.searchHistory);

  const searchResults = newSearchQuery.trim().length > 0
    ? internationalPricingData.filter(d =>
        d.productName.toLowerCase().includes(newSearchQuery.toLowerCase()) ||
        d.ingredient.toLowerCase().includes(newSearchQuery.toLowerCase())
      )
    : [];

  const handleSelect = (drug: DrugItem) => {
    setSelectedDrug(drug);
    setNewSearchQuery('');
    setSearchDropdown(false);
    setActiveTab('pricing');
    setExpandedHta(null);
    setExpandedApproval(null);
  };

  const handleNewSearch = () => {
    if (searchResults.length > 0) {
      handleSelect(searchResults[0]);
    }
  };

  return (
    <div className="min-h-screen bg-[#0D1117] text-white">
      {/* Header */}
      <div className="px-8 pt-8 pb-6 border-b border-[#1E2530]">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="w-5 h-5 flex items-center justify-center"><i className="ri-global-line text-[#00E5CC]"></i></span>
              <h1 className="text-2xl font-bold text-white">해외약가</h1>
            </div>
            <p className="text-[#8B9BB4] text-sm">A8 국가 급여 약가 및 HTA · 허가 현황</p>
          </div>
          <button className="flex items-center gap-2 bg-[#00E5CC] text-[#0A0E1A] text-sm font-semibold px-4 py-2 rounded-lg cursor-pointer whitespace-nowrap hover:bg-[#00C9B1] transition-colors">
            <span className="w-4 h-4 flex items-center justify-center"><i className="ri-download-2-line text-sm"></i></span>
            리포트 다운로드
          </button>
        </div>
      </div>

      <div className="px-8 py-6 space-y-5">

        {/* ── 기존 검색 이력 카드 ── */}
        <div>
          <div className="flex items-center gap-2 mb-3">
            <span className="w-4 h-4 flex items-center justify-center text-[#8B9BB4]"><i className="ri-history-line text-sm"></i></span>
            <p className="text-[#8B9BB4] text-xs font-semibold uppercase tracking-wider">기존 검색 이력</p>
            <span className="bg-[#1E2530] text-[#8B9BB4] text-xs px-2 py-0.5 rounded-full">{historyItems.length}건</span>
          </div>
          <div className="grid grid-cols-4 gap-3">
            {historyItems.map(drug => (
              <button
                key={drug.id}
                onClick={() => handleSelect(drug)}
                className={`text-left p-4 rounded-2xl border transition-all cursor-pointer group ${
                  selectedDrug?.id === drug.id
                    ? 'bg-[#00E5CC]/8 border-[#00E5CC]/40'
                    : 'bg-[#161B27] border-[#1E2530] hover:border-[#2A3545]'
                }`}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1 min-w-0">
                    <p className={`text-sm font-bold truncate ${selectedDrug?.id === drug.id ? 'text-[#00E5CC]' : 'text-white group-hover:text-[#00E5CC]'} transition-colors`}>
                      {drug.productName}
                    </p>
                    <p className="text-[#8B9BB4] text-xs mt-0.5 truncate">{drug.ingredient}</p>
                  </div>
                  {selectedDrug?.id === drug.id && (
                    <span className="w-5 h-5 flex items-center justify-center text-[#00E5CC] flex-shrink-0 ml-2">
                      <i className="ri-checkbox-circle-fill text-sm"></i>
                    </span>
                  )}
                </div>
                <div className="space-y-1.5">
                  <div className="flex items-center gap-1.5">
                    <span className="w-3.5 h-3.5 flex items-center justify-center text-[#4A5568]"><i className="ri-calendar-line text-xs"></i></span>
                    <span className="text-[#4A5568] text-xs">{drug.searchedAt}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="w-3.5 h-3.5 flex items-center justify-center text-[#4A5568]"><i className="ri-user-line text-xs"></i></span>
                    <span className="text-[#4A5568] text-xs truncate">{drug.searchedBy}</span>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* ── 신규 검색 ── */}
        <div className="bg-[#161B27] rounded-2xl border border-[#1E2530] p-5">
          <div className="flex items-center gap-2 mb-3">
            <span className="w-4 h-4 flex items-center justify-center text-[#00E5CC]"><i className="ri-search-2-line text-sm"></i></span>
            <p className="text-white text-sm font-semibold">신규 검색</p>
            <span className="text-[#4A5568] text-xs">이력에 없는 제품을 검색하세요</span>
          </div>
          <div className="flex gap-3 relative">
            <div className="flex-1 relative">
              <div className="flex items-center gap-3 bg-[#0D1117] border border-[#1E2530] rounded-xl px-4 py-3 focus-within:border-[#00E5CC]/50 transition-colors">
                <span className="w-4 h-4 flex items-center justify-center text-[#8B9BB4] flex-shrink-0">
                  <i className="ri-search-line text-sm"></i>
                </span>
                <input
                  type="text"
                  placeholder="영문 성분명 또는 제품명 입력 (예: Pembrolizumab, Keytruda)"
                  value={newSearchQuery}
                  onChange={e => { setNewSearchQuery(e.target.value); setSearchDropdown(true); }}
                  onFocus={() => newSearchQuery && setSearchDropdown(true)}
                  onKeyDown={e => e.key === 'Enter' && handleNewSearch()}
                  className="flex-1 bg-transparent text-white text-sm placeholder-[#4A5568] focus:outline-none"
                />
                {newSearchQuery && (
                  <button
                    onClick={() => { setNewSearchQuery(''); setSearchDropdown(false); }}
                    className="w-4 h-4 flex items-center justify-center text-[#4A5568] hover:text-white cursor-pointer transition-colors"
                  >
                    <i className="ri-close-line text-sm"></i>
                  </button>
                )}
              </div>

              {/* Dropdown */}
              {searchDropdown && searchResults.length > 0 && (
                <div className="absolute top-full left-0 right-0 mt-1 bg-[#161B27] border border-[#1E2530] rounded-xl overflow-hidden z-50">
                  {searchResults.map(d => (
                    <button
                      key={d.id}
                      onClick={() => handleSelect(d)}
                      className="w-full flex items-center gap-3 px-4 py-3 hover:bg-[#00E5CC]/8 transition-colors cursor-pointer text-left border-b border-[#1E2530] last:border-0"
                    >
                      <span className="w-7 h-7 rounded-lg bg-[#00E5CC]/10 flex items-center justify-center flex-shrink-0">
                        <i className="ri-capsule-line text-[#00E5CC] text-xs"></i>
                      </span>
                      <div className="flex-1 min-w-0">
                        <p className="text-white text-sm font-semibold">{d.productName}</p>
                        <p className="text-[#8B9BB4] text-xs">{d.ingredient}</p>
                      </div>
                      <span className="text-[#4A5568] text-xs whitespace-nowrap">검색 이력 있음</span>
                    </button>
                  ))}
                </div>
              )}
              {searchDropdown && newSearchQuery && searchResults.length === 0 && (
                <div className="absolute top-full left-0 right-0 mt-1 bg-[#161B27] border border-[#1E2530] rounded-xl px-4 py-3 z-50">
                  <p className="text-[#4A5568] text-sm">검색 결과가 없습니다</p>
                </div>
              )}
            </div>
            <button
              onClick={handleNewSearch}
              className="flex items-center gap-2 bg-[#00E5CC] text-[#0A0E1A] text-sm font-bold px-5 py-3 rounded-xl cursor-pointer whitespace-nowrap hover:bg-[#00C9B1] transition-colors"
            >
              <span className="w-4 h-4 flex items-center justify-center"><i className="ri-search-line text-sm"></i></span>
              검색
            </button>
          </div>
        </div>

        {/* ── 상세 패널 ── */}
        {selectedDrug ? (
          <div className="space-y-4">
            {/* Product Header + Tabs */}
            <div className="bg-[#161B27] rounded-2xl border border-[#1E2530] px-6 py-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-xl bg-[#00E5CC]/10 flex items-center justify-center flex-shrink-0">
                    <i className="ri-capsule-line text-[#00E5CC] text-lg"></i>
                  </div>
                  <div>
                    <h2 className="text-white text-lg font-bold">{selectedDrug.productName}</h2>
                    <p className="text-[#8B9BB4] text-sm">{selectedDrug.ingredient}</p>
                  </div>
                  <div className="flex items-center gap-3 ml-4 pl-4 border-l border-[#1E2530]">
                    <div className="flex items-center gap-1.5">
                      <span className="w-3.5 h-3.5 flex items-center justify-center text-[#4A5568]"><i className="ri-calendar-line text-xs"></i></span>
                      <span className="text-[#4A5568] text-xs">{selectedDrug.searchedAt}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className="w-3.5 h-3.5 flex items-center justify-center text-[#4A5568]"><i className="ri-user-line text-xs"></i></span>
                      <span className="text-[#4A5568] text-xs">{selectedDrug.searchedBy}</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-1 bg-[#0D1117] border border-[#1E2530] rounded-xl p-1">
                  {[
                    { key: 'pricing', label: 'A8 급여약가', icon: 'ri-money-dollar-circle-line' },
                    { key: 'hta', label: 'HTA 현황', icon: 'ri-shield-check-line' },
                    { key: 'approval', label: '허가 현황', icon: 'ri-file-check-line' },
                  ].map(tab => (
                    <button
                      key={tab.key}
                      onClick={() => setActiveTab(tab.key as 'pricing' | 'hta' | 'approval')}
                      className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium cursor-pointer transition-all whitespace-nowrap ${
                        activeTab === tab.key ? 'bg-[#00E5CC] text-[#0A0E1A]' : 'text-[#8B9BB4] hover:text-white'
                      }`}
                    >
                      <span className="w-4 h-4 flex items-center justify-center"><i className={`${tab.icon} text-xs`}></i></span>
                      {tab.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* ── A8 Pricing Tab ── */}
            {activeTab === 'pricing' && (
              <div className="bg-[#161B27] rounded-2xl border border-[#1E2530] overflow-hidden">
                <div className="px-5 py-4 border-b border-[#1E2530]">
                  <h3 className="text-white font-bold text-sm">A8 국가 급여 약가</h3>
                  <p className="text-[#4A5568] text-xs mt-0.5">미국 · 영국 · 독일 · 프랑스 · 캐나다 · 일본 · 이탈리아 · 스위스</p>
                </div>
                <div className="grid grid-cols-4 gap-0">
                  {A8_COUNTRIES.map((country, idx) => {
                    const pricing = (selectedDrug.a8Pricing as Record<string, { price: number; currency: string; reimbursed: boolean; reimbursedDate: string; note: string } | undefined>)[country.key];
                    return (
                      <div
                        key={country.key}
                        className={`p-5 ${idx % 4 !== 3 ? 'border-r border-[#1E2530]' : ''} ${idx >= 4 ? 'border-t border-[#1E2530]' : ''}`}
                      >
                        <div className="flex items-center gap-2 mb-3">
                          <span className="text-xl">{country.flag}</span>
                          <div className="flex-1 min-w-0">
                            <p className="text-white text-xs font-semibold">{country.label}</p>
                            <p className="text-[#4A5568] text-xs">{country.currency}</p>
                          </div>
                          {pricing?.reimbursed && (
                            <span className="text-xs px-1.5 py-0.5 rounded-full bg-emerald-400/10 text-emerald-400 font-semibold whitespace-nowrap">급여</span>
                          )}
                        </div>
                        {pricing ? (
                          <>
                            <p className="text-[#00E5CC] text-lg font-bold mb-1">
                              {getCurrencySymbol(country.currency)}{pricing.price.toLocaleString()}
                            </p>
                            {pricing.reimbursedDate && (
                              <p className="text-[#4A5568] text-xs">등재: {pricing.reimbursedDate}</p>
                            )}
                            {pricing.note && (
                              <p className="text-[#8B9BB4] text-xs mt-1">{pricing.note}</p>
                            )}
                          </>
                        ) : (
                          <p className="text-[#4A5568] text-sm">정보 없음</p>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* ── HTA Tab ── */}
            {activeTab === 'hta' && (
              <div className="space-y-3">
                <div className="bg-[#161B27] rounded-2xl border border-[#1E2530] px-5 py-3">
                  <h3 className="text-white font-bold text-sm">HTA 중심 국가 평가 현황</h3>
                  <p className="text-[#4A5568] text-xs mt-0.5">영국(NICE) · 캐나다(CADTH) · 호주(PBAC) · 스코틀랜드(SMC) — 항목을 클릭하면 상세 허가 문구를 확인할 수 있습니다</p>
                </div>
                {HTA_COUNTRIES.map(country => {
                  const hta = (selectedDrug.htaStatus as Record<string, { status: string; htaBody: string; date: string; recommendation: string; note: string; fullText: string } | undefined>)[country.key];
                  const isExpanded = expandedHta === country.key;
                  return (
                    <div key={country.key} className="bg-[#161B27] rounded-2xl border border-[#1E2530] overflow-hidden">
                      <button
                        onClick={() => setExpandedHta(isExpanded ? null : country.key)}
                        className="w-full flex items-center gap-4 px-5 py-4 hover:bg-[#1E2530]/50 transition-colors cursor-pointer text-left"
                      >
                        <span className="text-2xl flex-shrink-0">{country.flag}</span>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <p className="text-white text-sm font-bold">{country.label}</p>
                            <span className="text-[#4A5568] text-xs">({country.body})</span>
                            {hta && (
                              <span className={`text-xs px-2 py-0.5 rounded-full font-semibold ${getStatusBadgeClass(hta.status)}`}>
                                {hta.recommendation}
                              </span>
                            )}
                          </div>
                          {hta ? (
                            <div className="flex items-center gap-3">
                              <span className="text-[#8B9BB4] text-xs">평가일: {hta.date}</span>
                              <span className="text-[#4A5568] text-xs">|</span>
                              <span className="text-[#8B9BB4] text-xs">{hta.note}</span>
                            </div>
                          ) : (
                            <p className="text-[#4A5568] text-xs">평가 정보 없음</p>
                          )}
                        </div>
                        {hta && (
                          <div className="flex items-center gap-2 flex-shrink-0">
                            <span className="text-[#00E5CC] text-xs font-medium whitespace-nowrap">
                              {isExpanded ? '접기' : '상세 문구 보기'}
                            </span>
                            <span className="w-5 h-5 flex items-center justify-center text-[#00E5CC]">
                              <i className={`text-sm transition-transform duration-200 ${isExpanded ? 'ri-arrow-up-s-line' : 'ri-arrow-down-s-line'}`}></i>
                            </span>
                          </div>
                        )}
                      </button>

                      {/* Expanded Full Text */}
                      {isExpanded && hta?.fullText && (
                        <div className="px-5 pb-5 border-t border-[#1E2530]">
                          <div className="mt-4 bg-[#0D1117] rounded-xl p-4 border border-[#1E2530]">
                            <div className="flex items-center gap-2 mb-3">
                              <span className="w-4 h-4 flex items-center justify-center text-[#00E5CC]"><i className="ri-file-text-line text-xs"></i></span>
                              <p className="text-[#00E5CC] text-xs font-semibold uppercase tracking-wider">Official {country.body} Statement</p>
                            </div>
                            <p className="text-[#8B9BB4] text-xs leading-relaxed">{hta.fullText}</p>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}

            {/* ── Approval Tab ── */}
            {activeTab === 'approval' && (
              <div className="space-y-3">
                <div className="bg-[#161B27] rounded-2xl border border-[#1E2530] px-5 py-3">
                  <h3 className="text-white font-bold text-sm">제외국 허가 현황</h3>
                  <p className="text-[#4A5568] text-xs mt-0.5">A8 국가 + HTA 중심 국가 (호주, 스코틀랜드) — 항목을 클릭하면 상세 허가 문구를 확인할 수 있습니다</p>
                </div>
                {ALL_APPROVAL_COUNTRIES.map(country => {
                  const approval = (selectedDrug.approvalStatus as Record<string, { approved: boolean; date: string | null; indication: string | null; fullIndication: string | null } | undefined>)[country.key];
                  const isExpanded = expandedApproval === country.key;
                  const isApproved = approval?.approved;
                  return (
                    <div key={country.key} className="bg-[#161B27] rounded-2xl border border-[#1E2530] overflow-hidden">
                      <button
                        onClick={() => isApproved && setExpandedApproval(isExpanded ? null : country.key)}
                        className={`w-full flex items-center gap-4 px-5 py-4 transition-colors text-left ${isApproved ? 'hover:bg-[#1E2530]/50 cursor-pointer' : 'cursor-default'}`}
                      >
                        <span className="text-2xl flex-shrink-0">{country.flag}</span>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <p className="text-white text-sm font-bold">{country.label}</p>
                            {isApproved ? (
                              <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-400/10 text-emerald-400 border border-emerald-400/20 font-semibold">허가</span>
                            ) : (
                              <span className="text-xs px-2 py-0.5 rounded-full bg-red-400/10 text-red-400 border border-red-400/20 font-semibold">미허가</span>
                            )}
                          </div>
                          {isApproved && approval ? (
                            <div className="flex items-center gap-3">
                              <span className="text-[#8B9BB4] text-xs">최초 허가일: {approval.date}</span>
                              <span className="text-[#4A5568] text-xs">|</span>
                              <span className="text-[#8B9BB4] text-xs truncate">{approval.indication}</span>
                            </div>
                          ) : (
                            <p className="text-[#4A5568] text-xs">허가 정보 없음</p>
                          )}
                        </div>
                        {isApproved && approval?.fullIndication && (
                          <div className="flex items-center gap-2 flex-shrink-0">
                            <span className="text-[#00E5CC] text-xs font-medium whitespace-nowrap">
                              {isExpanded ? '접기' : '상세 허가 문구'}
                            </span>
                            <span className="w-5 h-5 flex items-center justify-center text-[#00E5CC]">
                              <i className={`text-sm transition-transform duration-200 ${isExpanded ? 'ri-arrow-up-s-line' : 'ri-arrow-down-s-line'}`}></i>
                            </span>
                          </div>
                        )}
                      </button>

                      {/* Expanded Full Indication */}
                      {isExpanded && approval?.fullIndication && (
                        <div className="px-5 pb-5 border-t border-[#1E2530]">
                          <div className="mt-4 bg-[#0D1117] rounded-xl p-4 border border-[#1E2530]">
                            <div className="flex items-center gap-2 mb-3">
                              <span className="w-4 h-4 flex items-center justify-center text-[#00E5CC]"><i className="ri-file-check-line text-xs"></i></span>
                              <p className="text-[#00E5CC] text-xs font-semibold uppercase tracking-wider">Official Indication / Approval Text</p>
                            </div>
                            <p className="text-[#8B9BB4] text-xs leading-relaxed">{approval.fullIndication}</p>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        ) : (
          <div className="bg-[#161B27] rounded-2xl border border-[#1E2530] py-16 text-center">
            <span className="w-12 h-12 flex items-center justify-center mx-auto mb-3 text-[#4A5568]">
              <i className="ri-global-line text-4xl"></i>
            </span>
            <p className="text-[#8B9BB4] text-sm mb-1">검색 이력에서 제품을 선택하거나</p>
            <p className="text-[#4A5568] text-xs">신규 검색으로 성분명 또는 제품명을 입력하세요</p>
          </div>
        )}
      </div>
    </div>
  );
}
