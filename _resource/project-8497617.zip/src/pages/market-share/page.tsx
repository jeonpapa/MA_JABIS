import { useState } from 'react';
import {
  PieChart, Pie, Cell, ResponsiveContainer, Sector,
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Legend, Tooltip,
  LineChart, Line,
} from 'recharts';
import { marketShareData } from '@/mocks/dashboardData';

const unitTrendData = [
  { quarter: 'Q1 24', Keytruda: 34.2, Opdivo: 22.1, Tecentriq: 14.2, Imfinzi: 11.8, Bavencio: 7.5 },
  { quarter: 'Q2 24', Keytruda: 35.4, Opdivo: 22.8, Tecentriq: 14.8, Imfinzi: 12.1, Bavencio: 8.0 },
  { quarter: 'Q3 24', Keytruda: 36.5, Opdivo: 23.2, Tecentriq: 15.3, Imfinzi: 12.3, Bavencio: 8.5 },
  { quarter: 'Q4 24', Keytruda: 37.1, Opdivo: 23.5, Tecentriq: 15.6, Imfinzi: 12.4, Bavencio: 8.7 },
  { quarter: 'Q1 25', Keytruda: 37.8, Opdivo: 23.9, Tecentriq: 15.8, Imfinzi: 12.4, Bavencio: 8.9 },
];

const revenueTrendData = [
  { quarter: 'Q1 24', Keytruda: 4820, Opdivo: 2940, Tecentriq: 1680, Imfinzi: 1240, Bavencio: 620 },
  { quarter: 'Q2 24', Keytruda: 5210, Opdivo: 3080, Tecentriq: 1790, Imfinzi: 1310, Bavencio: 680 },
  { quarter: 'Q3 24', Keytruda: 5680, Opdivo: 3240, Tecentriq: 1920, Imfinzi: 1380, Bavencio: 740 },
  { quarter: 'Q4 24', Keytruda: 6120, Opdivo: 3410, Tecentriq: 2050, Imfinzi: 1450, Bavencio: 790 },
  { quarter: 'Q1 25', Keytruda: 6540, Opdivo: 3590, Tecentriq: 2180, Imfinzi: 1520, Bavencio: 850 },
];

const productDatabase = [
  { id: 1, name: 'Keytruda', ingredient: 'Pembrolizumab', company: '한국MSD', category: '항암제', share: 37.8, color: '#00E5CC' },
  { id: 2, name: 'Opdivo', ingredient: 'Nivolumab', company: 'BMS', category: '항암제', share: 23.9, color: '#7C3AED' },
  { id: 3, name: 'Tecentriq', ingredient: 'Atezolizumab', company: 'Roche', category: '항암제', share: 15.8, color: '#F59E0B' },
  { id: 4, name: 'Imfinzi', ingredient: 'Durvalumab', company: 'AstraZeneca', category: '항암제', share: 12.4, color: '#EF4444' },
  { id: 5, name: 'Bavencio', ingredient: 'Avelumab', company: 'Pfizer/Merck KGaA', category: '항암제', share: 8.9, color: '#10B981' },
  { id: 6, name: 'Libtayo', ingredient: 'Cemiplimab', company: 'Sanofi', category: '항암제', share: 1.2, color: '#F97316' },
  { id: 7, name: 'Zynyz', ingredient: 'Retifanlimab', company: 'Incyte', category: '항암제', share: 0.8, color: '#EC4899' },
  { id: 8, name: 'Jemperli', ingredient: 'Dostarlimab', company: 'GSK', category: '항암제', share: 0.6, color: '#8B5CF6' },
  { id: 9, name: 'Elrexfio', ingredient: 'Elranatamab', company: 'Pfizer', category: '혈액암', share: 2.1, color: '#06B6D4' },
  { id: 10, name: 'Talvey', ingredient: 'Talquetamab', company: 'J&J', category: '혈액암', share: 1.8, color: '#84CC16' },
];

const CHART_COLORS = ['#00E5CC', '#7C3AED', '#F59E0B', '#EF4444', '#10B981'];

const renderActiveShape = (props: any) => {
  const { cx, cy, innerRadius, outerRadius, startAngle, endAngle, fill, payload, percent } = props;
  return (
    <g>
      <text x={cx} y={cy - 12} textAnchor="middle" fill="#fff" fontSize={13} fontWeight="bold">{payload.name}</text>
      <text x={cx} y={cy + 12} textAnchor="middle" fill="#00E5CC" fontSize={20} fontWeight="bold">{`${payload.value}%`}</text>
      <text x={cx} y={cy + 32} textAnchor="middle" fill="#8B9BB4" fontSize={11}>{`(${(percent * 100).toFixed(1)}%)`}</text>
      <Sector cx={cx} cy={cy} innerRadius={innerRadius} outerRadius={outerRadius + 8} startAngle={startAngle} endAngle={endAngle} fill={fill} />
      <Sector cx={cx} cy={cy} innerRadius={outerRadius + 12} outerRadius={outerRadius + 16} startAngle={startAngle} endAngle={endAngle} fill={fill} />
    </g>
  );
};

const UnitTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-[#1E2530] border border-[#2A3545] rounded-xl p-3 min-w-[140px]">
        <p className="text-[#8B9BB4] text-xs mb-2">{label}</p>
        {payload.map((p: any) => (
          <div key={p.dataKey} className="flex items-center justify-between gap-4">
            <span className="text-xs" style={{ color: p.color }}>{p.dataKey}</span>
            <span className="text-white text-xs font-bold">{p.value}%</span>
          </div>
        ))}
      </div>
    );
  }
  return null;
};

const RevenueTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-[#1E2530] border border-[#2A3545] rounded-xl p-3 min-w-[160px]">
        <p className="text-[#8B9BB4] text-xs mb-2">{label}</p>
        {payload.map((p: any) => (
          <div key={p.dataKey} className="flex items-center justify-between gap-4">
            <span className="text-xs" style={{ color: p.color }}>{p.dataKey}</span>
            <span className="text-white text-xs font-bold">₩{p.value.toLocaleString()}M</span>
          </div>
        ))}
      </div>
    );
  }
  return null;
};

const downloadExcel = (view: string) => {
  let csvContent = '';
  let filename = '';

  if (view === 'donut') {
    filename = 'Korean_Market_Share.csv';
    csvContent = 'Product,Market Share (%)\n';
    marketShareData.forEach(item => {
      csvContent += `${item.name},${item.value}\n`;
    });
  } else if (view === 'unit') {
    filename = 'Korean_Market_Unit_Trend.csv';
    const headers = ['Quarter', 'Keytruda', 'Opdivo', 'Tecentriq', 'Imfinzi', 'Bavencio'];
    csvContent = headers.join(',') + '\n';
    unitTrendData.forEach(row => {
      csvContent += `${row.quarter},${row.Keytruda},${row.Opdivo},${row.Tecentriq},${row.Imfinzi},${row.Bavencio}\n`;
    });
  } else if (view === 'revenue') {
    filename = 'Korean_Market_Revenue_Trend.csv';
    const headers = ['Quarter', 'Keytruda (M KRW)', 'Opdivo (M KRW)', 'Tecentriq (M KRW)', 'Imfinzi (M KRW)', 'Bavencio (M KRW)'];
    csvContent = headers.join(',') + '\n';
    revenueTrendData.forEach(row => {
      csvContent += `${row.quarter},${row.Keytruda},${row.Opdivo},${row.Tecentriq},${row.Imfinzi},${row.Bavencio}\n`;
    });
  }

  const bom = '\uFEFF';
  const blob = new Blob([bom + csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
};

export default function KoreanMarketPage() {
  const [activeIndex, setActiveIndex] = useState(0);
  const [view, setView] = useState<'donut' | 'unit' | 'revenue'>('donut');
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<typeof productDatabase>([]);
  const [selectedProduct, setSelectedProduct] = useState<typeof productDatabase[0] | null>(null);
  const [showDropdown, setShowDropdown] = useState(false);

  const handleSearch = (value: string) => {
    setSearchQuery(value);
    if (value.trim().length > 0) {
      const results = productDatabase.filter(
        p =>
          p.name.toLowerCase().includes(value.toLowerCase()) ||
          p.ingredient.toLowerCase().includes(value.toLowerCase()) ||
          p.company.toLowerCase().includes(value.toLowerCase())
      );
      setSearchResults(results);
      setShowDropdown(true);
    } else {
      setSearchResults([]);
      setShowDropdown(false);
      setSelectedProduct(null);
    }
  };

  const handleSelect = (product: typeof productDatabase[0]) => {
    setSelectedProduct(product);
    setSearchQuery(product.name);
    setShowDropdown(false);
  };

  const handleClear = () => {
    setSearchQuery('');
    setSearchResults([]);
    setShowDropdown(false);
    setSelectedProduct(null);
  };

  return (
    <div className="min-h-screen bg-[#0D1117] text-white">
      {/* Header */}
      <div className="px-8 pt-8 pb-6 border-b border-[#1E2530]">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="w-5 h-5 flex items-center justify-center"><i className="ri-pie-chart-2-line text-[#00E5CC]"></i></span>
              <h1 className="text-2xl font-bold text-white">Korean Market</h1>
            </div>
            <p className="text-[#8B9BB4] text-sm">국내 시장 점유율 현황 및 매출 추이 분석</p>
          </div>

          <div className="flex items-center gap-3">
            {/* Excel Download Button */}
            <button
              onClick={() => downloadExcel(view)}
              className="flex items-center gap-2 bg-[#161B27] border border-[#1E2530] text-[#8B9BB4] hover:text-white hover:border-[#2A3545] text-sm font-medium px-4 py-2 rounded-lg cursor-pointer whitespace-nowrap transition-all"
            >
              <span className="w-4 h-4 flex items-center justify-center"><i className="ri-file-excel-2-line text-sm"></i></span>
              엑셀 다운로드
            </button>

            {/* View Tabs */}
            <div className="flex items-center gap-1 bg-[#161B27] border border-[#1E2530] rounded-lg p-1">
              {[
                { key: 'donut', label: 'Market Share', icon: 'ri-pie-chart-2-line' },
                { key: 'unit', label: 'Unit Trend', icon: 'ri-bar-chart-grouped-line' },
                { key: 'revenue', label: 'Revenue Trend', icon: 'ri-line-chart-line' },
              ].map(tab => (
                <button
                  key={tab.key}
                  onClick={() => setView(tab.key as 'donut' | 'unit' | 'revenue')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium cursor-pointer whitespace-nowrap transition-all ${
                    view === tab.key ? 'bg-[#00E5CC] text-[#0A0E1A]' : 'text-[#8B9BB4] hover:text-white'
                  }`}
                >
                  <span className="w-3.5 h-3.5 flex items-center justify-center"><i className={`${tab.icon} text-xs`}></i></span>
                  {tab.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Search Bar */}
        <div className="mt-5 relative">
          <div className="flex items-center gap-3 bg-[#161B27] border border-[#1E2530] rounded-xl px-4 py-3 focus-within:border-[#00E5CC]/50 transition-colors">
            <span className="w-5 h-5 flex items-center justify-center text-[#8B9BB4] flex-shrink-0">
              <i className="ri-search-line text-base"></i>
            </span>
            <input
              type="text"
              placeholder="제품명 또는 성분명으로 검색... (예: Keytruda, Pembrolizumab)"
              value={searchQuery}
              onChange={e => handleSearch(e.target.value)}
              onFocus={() => searchQuery && setShowDropdown(true)}
              className="flex-1 bg-transparent text-white text-sm placeholder-[#4A5568] focus:outline-none"
            />
            {searchQuery && (
              <button onClick={handleClear} className="w-5 h-5 flex items-center justify-center text-[#4A5568] hover:text-white cursor-pointer transition-colors">
                <i className="ri-close-line text-sm"></i>
              </button>
            )}
          </div>

          {showDropdown && searchResults.length > 0 && (
            <div className="absolute top-full left-0 right-0 mt-1 bg-[#161B27] border border-[#1E2530] rounded-xl overflow-hidden z-50">
              {searchResults.map(product => (
                <button
                  key={product.id}
                  onClick={() => handleSelect(product)}
                  className="w-full flex items-center gap-3 px-4 py-3 hover:bg-[#1E2530] transition-colors cursor-pointer text-left"
                >
                  <span className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ backgroundColor: product.color }}></span>
                  <div className="flex-1 min-w-0">
                    <span className="text-white text-sm font-semibold">{product.name}</span>
                    <span className="text-[#8B9BB4] text-xs ml-2">{product.ingredient}</span>
                  </div>
                  <span className="text-[#4A5568] text-xs">{product.company}</span>
                  <span className="text-[#00E5CC] text-xs font-bold">{product.share}%</span>
                </button>
              ))}
            </div>
          )}

          {showDropdown && searchResults.length === 0 && searchQuery && (
            <div className="absolute top-full left-0 right-0 mt-1 bg-[#161B27] border border-[#1E2530] rounded-xl px-4 py-4 z-50">
              <p className="text-[#4A5568] text-sm text-center">검색 결과가 없습니다</p>
            </div>
          )}
        </div>
      </div>

      <div className="px-8 py-6 space-y-5">
        {/* Selected Product Detail */}
        {selectedProduct && (
          <div className="bg-[#161B27] rounded-2xl border border-[#00E5CC]/30 p-5">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <span className="w-3 h-3 rounded-full" style={{ backgroundColor: selectedProduct.color }}></span>
                <h3 className="text-white font-bold text-lg">{selectedProduct.name}</h3>
                <span className="text-[#8B9BB4] text-sm">({selectedProduct.ingredient})</span>
                <span className="bg-[#00E5CC]/10 text-[#00E5CC] text-xs px-2 py-0.5 rounded-full">{selectedProduct.category}</span>
              </div>
              <button onClick={handleClear} className="text-[#4A5568] hover:text-white cursor-pointer transition-colors">
                <i className="ri-close-line text-lg"></i>
              </button>
            </div>
            <div className="grid grid-cols-4 gap-4">
              {[
                { label: '제조사', value: selectedProduct.company, icon: 'ri-building-2-line' },
                { label: '시장 점유율', value: `${selectedProduct.share}%`, icon: 'ri-pie-chart-2-line', highlight: true },
                { label: '카테고리', value: selectedProduct.category, icon: 'ri-capsule-line' },
                { label: '순위', value: `#${[...productDatabase].sort((a, b) => b.share - a.share).findIndex(p => p.id === selectedProduct.id) + 1}`, icon: 'ri-trophy-line' },
              ].map(item => (
                <div key={item.label} className="bg-[#0D1117] rounded-xl p-4 border border-[#1E2530]">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="w-4 h-4 flex items-center justify-center text-[#8B9BB4]">
                      <i className={`${item.icon} text-sm`}></i>
                    </span>
                    <span className="text-[#8B9BB4] text-xs">{item.label}</span>
                  </div>
                  <p className={`text-base font-bold ${item.highlight ? 'text-[#00E5CC]' : 'text-white'}`}>{item.value}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Summary Row */}
        <div className="grid grid-cols-6 gap-3">
          {marketShareData.map(item => (
            <div key={item.name} className="bg-[#161B27] rounded-xl p-4 border border-[#1E2530]">
              <div className="flex items-center gap-2 mb-2">
                <span className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ backgroundColor: item.color }}></span>
                <span className="text-[#8B9BB4] text-xs truncate">{item.name}</span>
              </div>
              <p className="text-xl font-bold" style={{ color: item.color }}>{item.value}%</p>
            </div>
          ))}
        </div>

        {/* Main Chart */}
        <div className="bg-[#161B27] rounded-2xl p-6 border border-[#1E2530]">

          {/* ── Market Share Donut ── */}
          {view === 'donut' && (
            <div className="grid grid-cols-2 gap-8 items-center">
              <div>
                <h3 className="text-white font-bold text-base mb-1">Korean Market Share Distribution</h3>
                <p className="text-[#8B9BB4] text-xs mb-4">마우스를 올려 상세 정보 확인</p>
                <ResponsiveContainer width="100%" height={320}>
                  <PieChart>
                    <Pie
                      activeIndex={activeIndex}
                      activeShape={renderActiveShape}
                      data={marketShareData}
                      cx="50%"
                      cy="50%"
                      innerRadius={80}
                      outerRadius={130}
                      dataKey="value"
                      onMouseEnter={(_, index) => setActiveIndex(index)}
                    >
                      {marketShareData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} stroke="transparent" />
                      ))}
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="space-y-3">
                <h3 className="text-white font-bold text-base mb-4">제품별 점유율 상세</h3>
                {marketShareData.map((item, idx) => (
                  <div
                    key={item.name}
                    className={`p-3 rounded-xl border cursor-pointer transition-all ${activeIndex === idx ? 'border-[#00E5CC]/50 bg-[#00E5CC]/5' : 'border-[#1E2530] hover:border-[#2A3545]'}`}
                    onMouseEnter={() => setActiveIndex(idx)}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="w-3 h-3 rounded-full flex-shrink-0" style={{ backgroundColor: item.color }}></span>
                        <span className="text-white text-sm font-semibold">{item.name}</span>
                      </div>
                      <span className="text-white text-sm font-bold">{item.value}%</span>
                    </div>
                    <div className="w-full h-1.5 bg-[#1E2530] rounded-full overflow-hidden">
                      <div className="h-full rounded-full transition-all duration-500" style={{ width: `${item.value}%`, backgroundColor: item.color }}></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ── Unit Trend ── */}
          {view === 'unit' && (
            <div>
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-white font-bold text-base mb-1">Unit Trend — Market Share (%)</h3>
                  <p className="text-[#8B9BB4] text-xs">분기별 처방 단위 기준 시장 점유율 추이 · 2024 Q1 ~ 2025 Q1</p>
                </div>
              </div>
              <ResponsiveContainer width="100%" height={320}>
                <LineChart data={unitTrendData} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1E2530" />
                  <XAxis dataKey="quarter" tick={{ fill: '#8B9BB4', fontSize: 11 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: '#8B9BB4', fontSize: 11 }} axisLine={false} tickLine={false} unit="%" domain={[0, 50]} />
                  <Tooltip content={<UnitTooltip />} />
                  <Legend wrapperStyle={{ color: '#8B9BB4', fontSize: 12 }} />
                  {marketShareData.slice(0, 5).map((item, idx) => (
                    <Line
                      key={item.name}
                      type="monotone"
                      dataKey={item.name}
                      stroke={CHART_COLORS[idx]}
                      strokeWidth={2}
                      dot={{ fill: CHART_COLORS[idx], r: 4, strokeWidth: 0 }}
                      activeDot={{ r: 6, strokeWidth: 0 }}
                    />
                  ))}
                </LineChart>
              </ResponsiveContainer>
            </div>
          )}

          {/* ── Revenue Trend ── */}
          {view === 'revenue' && (
            <div>
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-white font-bold text-base mb-1">Revenue Trend — Sales (M KRW)</h3>
                  <p className="text-[#8B9BB4] text-xs">분기별 매출액 추이 (단위: 백만원) · 2024 Q1 ~ 2025 Q1</p>
                </div>
              </div>
              <ResponsiveContainer width="100%" height={320}>
                <LineChart data={revenueTrendData} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1E2530" />
                  <XAxis dataKey="quarter" tick={{ fill: '#8B9BB4', fontSize: 11 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: '#8B9BB4', fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={v => `${v.toLocaleString()}`} />
                  <Tooltip content={<RevenueTooltip />} />
                  <Legend wrapperStyle={{ color: '#8B9BB4', fontSize: 12 }} />
                  {marketShareData.slice(0, 5).map((item, idx) => (
                    <Line
                      key={item.name}
                      type="monotone"
                      dataKey={item.name}
                      stroke={CHART_COLORS[idx]}
                      strokeWidth={2}
                      dot={{ fill: CHART_COLORS[idx], r: 4, strokeWidth: 0 }}
                      activeDot={{ r: 6, strokeWidth: 0 }}
                    />
                  ))}
                </LineChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
