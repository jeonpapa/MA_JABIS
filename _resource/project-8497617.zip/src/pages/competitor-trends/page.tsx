import { useState } from 'react';
import { competitorData } from '@/mocks/dashboardData';

const BADGE_TYPES = ['전체', '신규 출시', '가격 변동', '임상 진행', '급여 등재', '파이프라인', '전략 변화'];

export default function CompetitorTrendsPage() {
  const [filter, setFilter] = useState('전체');
  const [search, setSearch] = useState('');
  const [expanded, setExpanded] = useState<number | null>(null);

  const filtered = competitorData.filter(d => {
    const matchBadge = filter === '전체' || d.badge === filter;
    const matchSearch = !search || d.company.toLowerCase().includes(search.toLowerCase()) || d.headline.toLowerCase().includes(search.toLowerCase());
    return matchBadge && matchSearch;
  });

  return (
    <div className="min-h-screen bg-[#0D1117] text-white">
      {/* Header */}
      <div className="px-8 pt-8 pb-6 border-b border-[#1E2530]">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="w-5 h-5 flex items-center justify-center"><i className="ri-bar-chart-grouped-line text-[#00E5CC]"></i></span>
              <h1 className="text-2xl font-bold text-white">Competitor Trends</h1>
            </div>
            <p className="text-[#8B9BB4] text-sm">경쟁사 동향 모니터링 및 전략 분석</p>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-2 bg-[#161B27] border border-[#1E2530] rounded-lg px-3 py-2">
              <span className="w-4 h-4 flex items-center justify-center text-[#8B9BB4]"><i className="ri-search-line text-sm"></i></span>
              <input
                type="text"
                placeholder="회사명 또는 키워드 검색..."
                value={search}
                onChange={e => setSearch(e.target.value)}
                className="bg-transparent text-white text-sm placeholder-[#4A5568] focus:outline-none w-48"
              />
            </div>
            <button className="flex items-center gap-2 bg-[#00E5CC] text-[#0A0E1A] text-sm font-semibold px-4 py-2 rounded-lg cursor-pointer whitespace-nowrap hover:bg-[#00C9B1] transition-colors">
              <span className="w-4 h-4 flex items-center justify-center"><i className="ri-add-line text-sm"></i></span>
              동향 추가
            </button>
          </div>
        </div>
      </div>

      <div className="px-8 py-6 space-y-5">
        {/* Stats */}
        <div className="grid grid-cols-4 gap-4">
          {[
            { label: '모니터링 경쟁사', value: '18', icon: 'ri-building-2-line', color: '#00E5CC' },
            { label: '이번 달 동향', value: '6', icon: 'ri-notification-3-line', color: '#7C3AED' },
            { label: '신규 출시 예정', value: '3', icon: 'ri-rocket-line', color: '#F59E0B' },
            { label: '가격 변동 건수', value: '2', icon: 'ri-exchange-dollar-line', color: '#EF4444' },
          ].map(stat => (
            <div key={stat.label} className="bg-[#161B27] rounded-xl p-4 border border-[#1E2530] flex items-center gap-4">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{ backgroundColor: stat.color + '20' }}>
                <span className="w-5 h-5 flex items-center justify-center" style={{ color: stat.color }}>
                  <i className={`${stat.icon} text-lg`}></i>
                </span>
              </div>
              <div>
                <p className="text-[#8B9BB4] text-xs">{stat.label}</p>
                <p className="text-xl font-bold" style={{ color: stat.color }}>{stat.value}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Filter Tabs */}
        <div className="flex gap-2 flex-wrap">
          {BADGE_TYPES.map(type => (
            <button
              key={type}
              onClick={() => setFilter(type)}
              className={`px-3 py-1.5 rounded-full text-xs font-medium cursor-pointer whitespace-nowrap transition-all ${
                filter === type ? 'bg-[#00E5CC] text-[#0A0E1A]' : 'bg-[#161B27] border border-[#1E2530] text-[#8B9BB4] hover:text-white'
              }`}
            >
              {type}
            </button>
          ))}
        </div>

        {/* Cards Grid */}
        <div className="grid grid-cols-3 gap-4">
          {filtered.map(item => (
            <div
              key={item.id}
              className="bg-[#161B27] rounded-2xl border border-[#1E2530] hover:border-[#2A3545] transition-all duration-200 overflow-hidden"
            >
              <div className="p-5">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2.5">
                    <div
                      className="w-9 h-9 rounded-xl flex items-center justify-center text-xs font-bold text-white flex-shrink-0"
                      style={{ backgroundColor: item.color + '25', border: `1px solid ${item.color}40` }}
                    >
                      {item.logo}
                    </div>
                    <div>
                      <p className="text-white text-xs font-semibold leading-tight">{item.company}</p>
                      <p className="text-[#4A5568] text-xs">{item.date}</p>
                    </div>
                  </div>
                  <span className={`text-xs font-semibold px-2 py-1 rounded-full whitespace-nowrap ${item.badgeColor}`}>
                    {item.badge}
                  </span>
                </div>

                <h4 className="text-white text-sm font-bold mb-2 leading-snug">{item.headline}</h4>
                <p className={`text-[#8B9BB4] text-xs leading-relaxed ${expanded === item.id ? '' : 'line-clamp-2'}`}>
                  {item.detail}
                </p>

                <div className="flex items-center justify-between mt-4">
                  <div className="flex items-center gap-1.5">
                    <span className="w-3.5 h-3.5 flex items-center justify-center text-[#4A5568]"><i className="ri-file-text-line text-xs"></i></span>
                    <span className="text-[#4A5568] text-xs">{item.source}</span>
                  </div>
                  <button
                    onClick={() => setExpanded(expanded === item.id ? null : item.id)}
                    className="flex items-center gap-1 text-[#00E5CC] text-xs font-medium cursor-pointer whitespace-nowrap hover:text-[#00C9B1] transition-colors"
                  >
                    {expanded === item.id ? '접기' : '더 보기'}
                    <span className="w-3.5 h-3.5 flex items-center justify-center">
                      <i className={`text-xs ${expanded === item.id ? 'ri-arrow-up-s-line' : 'ri-arrow-down-s-line'}`}></i>
                    </span>
                  </button>
                </div>
              </div>

              {/* Bottom accent bar */}
              <div className="h-0.5 w-full" style={{ backgroundColor: item.color + '60' }}></div>
            </div>
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-16 text-[#4A5568]">
            <span className="w-12 h-12 flex items-center justify-center mx-auto mb-3"><i className="ri-search-line text-4xl"></i></span>
            <p className="text-sm">검색 결과가 없습니다</p>
          </div>
        )}
      </div>
    </div>
  );
}
