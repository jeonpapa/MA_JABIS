export const ADMIN_EMAIL = 'admin@marketintel.kr';
export const ADMIN_PASSWORD_KEY = 'app_admin_password';
export const USERS_KEY = 'app_users_list';

export interface AppUser {
  email: string;
  password: string;
  role: 'admin' | 'user';
  createdAt: string;
}

const DEFAULT_ADMIN: AppUser = {
  email: ADMIN_EMAIL,
  password: 'admin1234',
  role: 'admin',
  createdAt: '2026-01-01',
};

export function getUsers(): AppUser[] {
  try {
    const raw = localStorage.getItem(USERS_KEY);
    if (!raw) return [DEFAULT_ADMIN];
    const parsed: AppUser[] = JSON.parse(raw);
    // admin 항상 포함 보장
    const hasAdmin = parsed.some(u => u.email.toLowerCase() === ADMIN_EMAIL.toLowerCase());
    if (!hasAdmin) return [DEFAULT_ADMIN, ...parsed];
    return parsed;
  } catch {
    return [DEFAULT_ADMIN];
  }
}

export function saveUsers(users: AppUser[]): void {
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
}

export function isAdmin(email: string): boolean {
  return email.toLowerCase() === ADMIN_EMAIL.toLowerCase();
}

export function getCurrentUser(): string {
  return localStorage.getItem('app_current_user') || '';
}

export function addUser(email: string, password: string): { ok: boolean; error?: string } {
  const users = getUsers();
  if (users.some(u => u.email.toLowerCase() === email.toLowerCase())) {
    return { ok: false, error: '이미 등록된 이메일입니다.' };
  }
  const newUser: AppUser = {
    email: email.trim(),
    password,
    role: 'user',
    createdAt: new Date().toISOString().split('T')[0],
  };
  saveUsers([...users, newUser]);
  return { ok: true };
}

export function removeUser(email: string): void {
  const users = getUsers().filter(u => u.email.toLowerCase() !== email.toLowerCase());
  saveUsers(users);
}

export function updateAdminCredentials(newEmail: string, newPassword: string): void {
  const users = getUsers();
  const updated = users.map(u => {
    if (u.email.toLowerCase() === ADMIN_EMAIL.toLowerCase()) {
      return { ...u, email: newEmail, password: newPassword };
    }
    return u;
  });
  saveUsers(updated);
  localStorage.setItem('app_current_user', newEmail);
}
