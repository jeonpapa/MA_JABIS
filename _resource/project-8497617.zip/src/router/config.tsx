import { RouteObject } from 'react-router-dom';
import HomePage from '@/pages/home/page';
import DomesticPricingPage from '@/pages/domestic-pricing/page';
import InternationalPricingPage from '@/pages/international-pricing/page';
import MarketSharePage from '@/pages/market-share/page';
import DailyMailingPage from '@/pages/daily-mailing/page';
import LoginPage from '@/pages/login/page';
import NotFound from '@/pages/NotFound';

const routes: RouteObject[] = [
  { path: '/login', element: <LoginPage /> },
  { path: '/', element: <HomePage /> },
  { path: '/domestic-pricing', element: <DomesticPricingPage /> },
  { path: '/international-pricing', element: <InternationalPricingPage /> },
  { path: '/market-share', element: <MarketSharePage /> },
  { path: '/daily-mailing', element: <DailyMailingPage /> },
  { path: '*', element: <NotFound /> },
];

export default routes;
