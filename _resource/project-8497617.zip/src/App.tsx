import { BrowserRouter, useLocation, Navigate } from "react-router-dom";
import { AppRoutes } from "./router";
import { I18nextProvider } from "react-i18next";
import i18n from "./i18n";
import Sidebar from "@/components/feature/Sidebar";

function AuthGuard({ children }: { children: React.ReactNode }) {
  const location = useLocation();
  const isAuthed = localStorage.getItem('app_authed') === '1';
  const autoLogin = localStorage.getItem('app_auto_login') === '1';
  const isLoginPage = location.pathname === '/login';

  // 자동 로그인: authed + auto_login 플래그 모두 있으면 통과
  const effectivelyAuthed = isAuthed || autoLogin;

  if (!effectivelyAuthed && !isLoginPage) {
    return <Navigate to="/login" replace />;
  }
  if (effectivelyAuthed && isLoginPage) {
    return <Navigate to="/" replace />;
  }
  return <>{children}</>;
}

function Layout() {
  const location = useLocation();
  const isLoginPage = location.pathname === '/login';

  if (isLoginPage) {
    return <AppRoutes />;
  }

  return (
    <div className="flex min-h-screen bg-[#0D1117]">
      <Sidebar />
      <main className="flex-1 ml-60 min-h-screen overflow-y-auto">
        <AppRoutes />
      </main>
    </div>
  );
}

function App() {
  return (
    <I18nextProvider i18n={i18n}>
      <BrowserRouter basename={__BASE_PATH__}>
        <AuthGuard>
          <Layout />
        </AuthGuard>
      </BrowserRouter>
    </I18nextProvider>
  );
}

export default App;
